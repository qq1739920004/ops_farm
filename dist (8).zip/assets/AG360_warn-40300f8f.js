const a=""+new URL("AG360-71c3ea38.svg",import.meta.url).href,r=""+new URL("AG360_warn-f394591a.svg",import.meta.url).href;export{r as A,a};
