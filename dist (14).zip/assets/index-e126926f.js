import{A as se,a as ne}from"./AG360_warn-40300f8f.js";import{S as oe,A as de,y as ce,g as Ae,__tla as ue}from"./index-fbb10192.js";import ve,{__tla as me}from"./realTimeChart-3867dffc.js";import{_ as pe,__tla as ke}from"./index.vue_vue_type_script_setup_true_lang-2ffb1d7d.js";import{s as ye,__tla as ge}from"./socket-21368d8e.js";import{d as fe,r as A,g as ra,A as he,x as Se,y as be,B as Te,C as we,a as _e,o as Ie,h as I,c as h,k as f,u as o,j as t,w as R,D as Re,b as sa,t as s,p as na,F as De,q as Ue,G as oa,H as Ce,I as Ge,f as g,e as D,_ as xe,__tla as Be}from"./index-06a624b7.js";import{f as Ne,o as Pe,__tla as Ee}from"./index-5d6ccb13.js";import"./gcoord.esm-bundler-25b3e209.js";import"./index-9a6536ad.js";import{__tla as Ke}from"./remoteAdjust-423e0989.js";import{__tla as Me}from"./index-fe32cb93.js";import{__tla as Je}from"./index-96ae4e38.js";import{__tla as Le}from"./remoteAdjust302-b416c5c0.js";import{__tla as ze}from"./remoteAdjust502-8f57ddbd.js";import{__tla as Ye}from"./remoteAdjust501Pro-80ccff9e.js";import{__tla as Oe}from"./remoteAdjust360-788a0955.js";let da,Xe=Promise.all([(()=>{try{return ue}catch{}})(),(()=>{try{return me}catch{}})(),(()=>{try{return ke}catch{}})(),(()=>{try{return ge}catch{}})(),(()=>{try{return Be}catch{}})(),(()=>{try{return Ee}catch{}})(),(()=>{try{return Ke}catch{}})(),(()=>{try{return Me}catch{}})(),(()=>{try{return Je}catch{}})(),(()=>{try{return Le}catch{}})(),(()=>{try{return ze}catch{}})(),(()=>{try{return Ye}catch{}})(),(()=>{try{return Oe}catch{}})()]).then(async()=>{const ca="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAA2hJREFUSEu1lV2IE1cYht9vJlHr2ouCuwheVKVQUGxxcybbSnshgiJiaanuVdEWUcQ/xD+qNJOZSVWEVUorgihebCvY3d4USlvqhQuF2s2cWX+WFQTZq15WK/5ArZvz1ZPM2UwmE7FIB0ImOZn3ec/7ne8L4X++6EX1CzL4lhg9tp3bMdp7+GZa74UAIqycB/iTWHTCtnP9acgzAX1jRxdnudKCIgy+ArATwAQUfweLyvo+DckELL7szel62RpkxgdE+DwUbim5dREGxwEcTAqKUd/LgrQBnKo3j8n6BsDKujtgCRMGIuEeaDivlAH2stwmIVM59c61Zd69FkDvb95rVt6+AHARin07nx+q1aaGNATAKem4u0RYGQJ4QxZAR2p+b9u5JTreFoCoBhKEghaXfWXtErGr9RpCjHNh0d2SBUmKM3F/JMrD+vlWgHEXA4y4LpxxxswXYOF7YtI701e9sNPrCfE2QJxxIwLFPixab05F0qERjt91fHGtms7Nocg8RdMRJKLSD7RAUjUysfRWg48t5gUm4o598LyQfI2/VF2YPfqm94c24YTeIib7JgPvRaL0yzMb7Xkg0nHbNERYuQhgXDqlI22LBelv0AVk4mORKB9OQzqdFhEGlwHlS8cbEaG/GaB10nHfbwEYcYCG64UmDIKx0RTRFL7RfK0FFWHlKhGfDYV7OjZxSTru/GlAUlw6pf7EWX9o27m+RMMhLR7Ppt8BXJSO+8XSXz99Zeas2bek4/bUAWlxc8QMRAvmrPzElJo68LTLfzRN1DKfqsEdgloZFr1rIvQ/BKw90im9S53EsyBZwqZ3mNW9qFjeWj9JVf80E82Ujrs5AUDb1pvw5tqysaPdM4BuPWd6o6BgKfTrycqkuiPh/RnnfwWwdkrns69TETWFkuIANknHHYyzNqNaf3zwtODD/9y9v/vG6oFHdfcy+BmKJ8NieXvLqEi7bc4a2iad0plk3suvez1PHluvdj1S4yMrvL/NWkH6a4nphzlz1UsjCxvfdzimjUdYYV/U557UQ49tzNB9kQSZex2VXcNeJrytrPyqscKh2x1n0XSjMblRsVRJzKABAGsAPAToJyY1TEwfAXhdv4j5RFgs708b+M9/+m9d8RbUbFrBZK3RECaafJLPT46/ceivrN39C/XTLzcrnO5+AAAAAElFTkSuQmCC",Aa="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAy9JREFUSEu1lV2ITVEUx9c63TsyedHkdvc6Z5q5UorHKVI8SCmJCPMkH4nkK/l6UJgJSSGhKZEHTI3hRQnxwBsPihKlNNNtZu89TUShbs3MXqzbObd9zz1XJLfOw93nnP9vrf/6OAj/+Yf/qq+1voOIBUTcrZR6n9b7J4DW+gYibhVRRHwHAN1pyG8B1tp5WVGJoNb6MiLuEWHn3D1EPJEFyQSMj4/PmJycvAkAa4MgOFUsFo/5qVtrzzLzEV9Qa92TBWkADA8PF1taWm4j4jIRYOb5iHhOKXVYINbaE8wsYg2W+JBKpbK4VCp9rQOMjIzMyeVy/cy8gJl7gyAYBIDBGHJFKbXXGCNnG7IAYqn3/Hyxtw5gjHkFAF0iHoZhT+x1TxAE6wUCANeJaHsWJCUuxb5bLb7vbfJiApCURVy6I4kMAPoR8T4zSya17vEir4k3AOTAhyTikqofoScMsX1JrerEMwFpSGJVXOCaxxk1qoqPjo5uQcTO5L2mc5C2K7HSz0QgzrlLra2trW1tbaPyTLlcnp3P52WiVxPRk98O2p9AiKhBQ2s9gIhvieh0w01r7Ya4gGeI6Gga0qxbjDHPpqametvb259rrbch4ioiWlMH8MSlxaTXbzLzpmTgYt+rLYuIdQU1xrxGxGtKqT4Jwjn3NAzDsAbwxYmoO4kcAL4j4kKvTaU1G7rFWvuSmQeI6GK5XJ6Zz+c/EFGhCkiLJwX1BkrmQFaDrIuHyRD5M6S1/szMy6IoemOMWQcA+4loCTYTz4JkCXtt/ZWIdsT/+5h5WhiG23xAQ+oevHbPWjsLAGbJ8BljusQu2axyRkSfxH9mfgEAe4joVtoiXyjpJjnbrJSS9S12Vld1nOE3RLyLiPuKxeKPOPrHADBERLvqJjkdbbJrAGAnEV31/R4bGyswc0elUnlbKpUq3hCuZOYHSqnpiFg9b9am1XeccwejKLoQ7/kWmYv0NzeOugsADgDAolwut7xQKHxMnms6aM6541EUnUx2EDOfA4AV0rYA8Eiscc5tRMS5ACDXeSI6lA7grz/61tpOAFjKzCsE8msQhyYmJoY6Ojq+ZGX3E1w7QTfMRN4lAAAAAElFTkSuQmCC",ua="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB0AAAAYCAYAAAAGXva8AAAAAXNSR0IArs4c6QAAAQxJREFUSEtjZKAheP78uej///9fwayQkpJiBLHBBK3A48ePHZiZmfePWkpxCD979uw/zBBGRkZFSUnJBzQPXmRL//796ygrK3tg1FKSssyLFy/E/v37dwgp7oIkJSWvgfg0C94HDx5IsrGxPUNKdaZSUlJnRi0lOfU+f/580////3lBQSclJeUIomkevNgSxtC21PhMqyTj/9/qoOA7Y9pwAJYyaepTk9NN8DKTgeGfI8ziUUupUjiMzOBlZmbRPmlUhVGAMzIyaoMK9kePHimzsLDcgaVwJiYmSwkJiRPoZS9M/fPnz7X+//9/leI20qtXr1R///79g42NjUtUVPQmOU0Okqo2cizApgcAZhKuKKDYqz8AAAAASUVORK5CYII=",va="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB0AAAAYCAYAAAAGXva8AAAAAXNSR0IArs4c6QAAAQ9JREFUSEtjZKAheP78uej///9fwayQkpJiBLHBBK3A48ePHZiZmfePWkpxCD979uw/zBBGRkZFSUnJBzQPXmRL//796ygrK3tg1FKSssyLFy/E/v37dwgp7oIkJSWvgfg0C94HDx5IsrGxPUNKdaZSUlJnRi0lOfWanG7axMDAwAsKujOmdY4gmubBa3K6CZ7ZGRj+OZ4xbTgwtC01PtMqyfj/tzokGBsOwFImTX2KzXCQxaOWUqVwGJnBy8zMon3SqApcgCOHAEz80aNHyiwsLHdgKZyJiclSQkLiBHrZy8jIqA2qCJ4/f671////qxS3kV69eqX6+/fvH2xsbFyioqI3yWlykFS1kWMBNj0ADxubKCvCq44AAAAASUVORK5CYII=",ma="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB0AAAAYCAYAAAAGXva8AAAAAXNSR0IArs4c6QAAAQxJREFUSEtjZKAhuH37tigDA8MrmBWqqqqMIDaYoBW4ffu2AwMDw/5RSykO4du3b/+HGfLnzx9FTU3NBzQPXmRLGRgYHFVVVQ+MWkpSltE72iDGxsZ0CBZ3zMwsQSeNqq6B+DQLXuMzrZKM//8+g1nK9O+f6SnzhjOjlpKcek1ON21iYGDgBQXdGdM6RxBN8+A1Od0Ez+wMDP8cz5g2HBjalkJc/1sdEowNB2Apk6Y+xWY4yOJRS6lSOIzM4GVmZtGGFeDIIQATNz7TrMz4//8dWAr/x8Rkec645gSWsldbVVX12u3bt7UYGBiuUtxGMj/frPrvN+OP/4z/uc6Y1t4kp8lBUtVGjgXY9AAAi9WZKEsg030AAAAASUVORK5CYII=",pa="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB0AAAAYCAYAAAAGXva8AAAAAXNSR0IArs4c6QAAAPxJREFUSEtjZKAheP78uej///9fwayQkpJiBLHBBK3A48ePHZiZmfePWkpxCJucbvoPM+TPn3+KFywbHtA8eJEtZWD453jGtOHAqKUkZRm9ow1ibGxMh2Bxx8zMEnTSqOoaiE+z4DU+0yrJ+P/vM5ilTP/+mZ4ybzgzainJqdfkdNMmBgYGXlDQnTGtcwTRNA9ebAljaFsKcf1vdUgwNhyApUya+hSb4biyANWCd9TS4R2nzMws2tgKcJi48ZlmZcb//+/AUvg/JibLc8Y1J9ATHkz98+fPtf7//3+V4jaS+flm1X+/GX/8Z/zPdca09iY5TQ6SqjZyLMCmBwDrva8oHPTaGAAAAABJRU5ErkJggg==",ka="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB0AAAAYCAYAAAAGXva8AAAAAXNSR0IArs4c6QAAAPtJREFUSEtjZKAhMDzXJsr8988rmBVnTOsYQWwwQStgcrrBgYGBaf+opRSHsMnppv8wQ/78+ad4wbLhAc2DF9lSBoZ/jmdMGw6MWkpSltE72iDGxsZ0CBZ3zMwsQSeNqq6B+DQLXuMzrZKM//8+g1nK9O+f6SnzhjOjlpKcek1ON21iYGDgBQXdGdM6RxBN8+DFljCGtqUQ1/9WhwRjwwFYyqSpT7EZjisLUC14Ry0d3nHKzMyija0Ah4kbn2lWZvz//w4shf9jYrI8Z1xzAj3hwdSbn2vT+vv3z1WK20jm55tV//1m/PGf8T/XGdPam+Q0OUiq2sixAJseALL5riimuPLmAAAAAElFTkSuQmCC",U=G=>(Ce("data-v-52238952"),G=G(),Ge(),G),ya={class:"map_container"},ga={class:"search_box"},fa={key:0},ha={key:0},Sa={key:1},ba={key:1},Ta={key:0},wa={key:2},_a={class:"top"},Ia={class:"top_line"},Ra={class:"top_line"},Da={class:"top_line"},Ua={class:"outside"},Ca=U(()=>t("div",{class:"offline_area"},null,-1)),Ga={style:{"text-overflow":"ellipsis",overflow:"hidden"}},xa=U(()=>t("div",{style:{height:"2px",width:"100%","background-color":"rgba(0, 218, 216, 0.3)",margin:"15px 0"}},null,-1)),Ba={class:"bottom_li"},Na=U(()=>t("div",null,null,-1)),Pa={class:"bottom_li"},Ea=U(()=>t("div",null,null,-1)),Ka={class:"center"},Ma={class:"label"},Ja={class:"value"},La={class:"value"},za=U(()=>t("br",null,null,-1)),Ya=fe({__name:"index",setup(G){const S=A(),{t:u}=ra(),{locale:Oa}=ra(),E=A(null);let Xa=500;const K=he(),z=Se(),x=ye();let M=A([]),Y=A([]),T=A({}),r=A({});const J=A(!0),B=A(!1);let N=A(),O=A(),X=A(),j=A(),H=A(),Q=A(),q=A(),L=A(!1);const F=A(""),C=be({markerId:"",mapCenter:[]});window.goMachineryList_markerPopup=$a,window.goTaskMachine_markerPopup=ae,window.gohistoryChart_markerPopup=ee,window.openRealTimeChart_markerPopup=le,window.openRemote_markerPopup=ie,Te(()=>x.socketData,a=>{Fa(a)},{deep:!0});function ja(){let a=E.value.parentNode.offsetWidth;E.value.offsetWidth>a?J.value=!1:J.value=!0}const Ha=we(()=>Oa.value=="zh"?"280px":"350px");_e(()=>{x.close()}),Ie(()=>{x.connect()}),Va(),Za();function Qa(a,i){let e=M.value.filter(l=>{if(l.sn&&l.sn.includes(a)||l.npn&&l.npn.includes(a)||l.carName&&l.carName.includes(a)||l.companyName&&l.companyName.includes(a)||l.tel&&l.tel.includes(a))return!0});if(e.length<=0){i(["\u65E0\u6570\u636E"]);return}e.length>3&&(e.length=3),e.forEach(l=>{l.border=!0,l.value=l.sn}),e[e.length-1].border=!1,i(e)}function qa(a){a.markerId&&(C.markerId="",C.markerId=a.markerId)}function Fa(a){if(a.module=="farm"&&a.type=="farmPt"){let{action:i,data:e}=a;if(i=="upline")if(S.value.isIconChange){const l=e.sn,d=e.posY,v=e.posX,m=e.onlineTcp,c=e.driveState,p=w(e),k=S.value.iconChangeLimit?b(e):P(e),y=_(e);T.value={markerId:l,onlineTcp:m,driveState:c,markerLng:d,markerLat:v,markerType:p,markerIcon:k,markerPopup:y,markerHandle:"add"}}else{const l=e.sn,d=e.posY,v=e.posX,m=w(e),c=b(e),p=_(e),k=e.onlineTcp,y=e.driveState;T.value={markerId:l,onlineTcp:k,driveState:y,markerLng:d,markerLat:v,markerType:m,markerIcon:c,markerPopup:p,markerHandle:"add"}}if(i=="offline")if(S.value.isIconChange){const l=e.sn,d=e.posY,v=e.posX,m=e.onlineTcp,c=e.driveState,p=w(e),k=S.value.iconChangeLimit?b(e):P(e),y=_(e);T.value={markerId:l,onlineTcp:m,driveState:c,markerLng:d,markerLat:v,markerType:p,markerIcon:k,markerPopup:y,markerHandle:"delete"}}else{const l=e.sn,d=e.posY,v=e.posX,m=w(e),c=b(e),p=_(e),k=e.onlineTcp,y=e.driveState;T.value={markerId:l,onlineTcp:k,driveState:y,markerLng:d,markerLat:v,markerType:m,markerIcon:c,markerPopup:p,markerHandle:"delete"}}if(i=="online")if(S.value.isIconChange){const l=S.value.iconChangeLimit?b(e):P(e),d=e.sn,v=e.posY,m=e.onlineTcp,c=e.driveState,p=e.posX,k=w(e),y=_(e);T.value={markerId:d,markerLng:v,markerLat:p,onlineTcp:m,driveState:c,markerType:k,markerIcon:l,markerPopup:y,markerHandle:"update"}}else{const l=b(e),d=e.sn,v=e.posY,m=e.posX,c=e.onlineTcp,p=e.driveState,k=w(e),y=_(e);T.value={markerId:d,markerLng:v,markerLat:m,onlineTcp:c,driveState:p,markerType:k,markerIcon:l,markerPopup:y,markerHandle:"update"}}}if(a.module=="farm"&&a.type=="monitor"){const{data:i}=a;r.value.device.totalDevice=i.totalDevice,r.value.device.onlineDevice=i.onlineDevice,r.value.drive.driving=i.driving,r.value.drive.standbyDevice=i.standbyDevice;const e=i.typeCounts;r.value.type.forEach((l,d)=>{l.onlineCount=e[d].onlineCount,l.totalCount=e[d].totalCount})}if(a.module=="farm"&&a.type=="monitorArea"){const{data:i}=a;r.value.workArea.todayArea=i.todayArea,r.value.workArea.totalArea=i.totalArea,r.value.workDuration.todayDuration=i.todayDuration,r.value.workDuration.beforeDuration=i.beforeDuration}if(a.module=="farm"&&a.type=="monitorCarNum"){const{data:i}=a;r.value.drive.driving=i.driving,r.value.drive.standbyDevice=i.standbyDevice,r.value.device.onlineDevice=i.driving+i.standbyDevice}}async function Va(){const{data:a}=await Ne();r.value=a,r.value.type.forEach(i=>i.checked=!0)}async function Za(){const{data:a}=await Pe({});let i=a.onlineFarmMachines,e=[];i.map(l=>{l.posX!==null&&e.push(l)}),i.forEach(l=>{l.markerId=l.sn,l.markerLng=l.posY,l.markerLat=l.posX,l.markerType=w(l),e.length>Xa?S.value.iconChangeLimit?l.markerIcon=b(l):l.markerIcon=P(l):l.markerIcon=b(l),l.markerPopup=_(l),l.driveState=l.driveState}),i=i.filter(l=>l.markerLng||l.markerLng==0),M.value=i,z.query.markerId&&(C.markerId=z.query.markerId),C.center=i.map(l=>[l.posY,l.posX])}function Wa(){let a=r.value.type.filter(i=>!i.checked);a=a.map(i=>i.typeName),Y.value=a}function w(a){return a.terminalType&&a.terminalType.includes("AG360")?"AG360":a.terminalType&&a.terminalType.includes("AG501")&&a.terminalType!="AG501Pro"?"AG501":a.terminalType&&a.terminalType=="AG501Pro"?"AG501Pro":a.terminalType&&a.terminalType.includes("AG502")?"AG502":a.terminalType&&a.terminalType.includes("AG302")&&a.terminalType!="AG302Android"?"AG302":a.terminalType&&a.terminalType=="AG302Android"?"AG302Android":a.terminalType&&a.terminalType.includes("MC100")?"MC100":a.terminalType&&a.terminalType.includes("SA200")?"SA200":a.terminalType&&a.terminalType.includes("MT801")?"MT801Pro":a.terminalType&&a.terminalType.includes("MT802")?"MT802":""}function _(a){const i={0:"\u975E\u81EA\u52A8\u9A7E\u9A76",1:"\u81EA\u52A8\u9A7E\u9A76",2:"\u81EA\u52A8\u9A7E\u9A76"},e={0:"status_1",1:"status_2",2:"status_3",null:"status_1"},l={\u4F18:"status_3",\u4E2D:"status_2",\u5DEE:"status_0",null:"status_1"},d={0:"\u65E0\u6548\u89E3",1:"\u5355\u70B9\u89E3",2:"\u5DEE\u5206\u89E3",3:"\u6D6E\u52A8\u89E3",4:"\u56FA\u5B9A\u89E3"},v={0:"\u7535\u53F0",1:"\u7F51\u7EDC",3:"\u7F57\u7F51"},m={0:ua,1:va,2:ma,3:pa,4:ka};let c=!0;a.onlineTcp===0||a.driveState!=0?c=!1:c=!0;const p=a.cardUsage==1?"\u53611":a.cardUsage==2?"\u53612":"\u53CC\u5361";return`<div class="map_popup">

        <ul class="popup_container">
         <li>
            <div class="le">
            
              <span > <img class="sate" src= ${a.onlineTcp==0?Aa:ca}></span>
             <span class="value">${a.satNum||"--"}</span>
            </div>
            <div class="re" >
              <div class="value" style="margin-left: auto;margin-right:20px">
                <img src=${m[a.netSignal]}>
                <span>4G</span>
              </div>
            </div>
          </li>
          <li>
            <div class="l">
              <div class="label">${u("messages.carName")}</div>
              <div class="value">${a.carName||"--"}</div>
            </div>
            <div class="r">
              <div class="label">SN</div>
              <div class="value"  style="cursor: pointer;text-decoration: underline;" onclick='goMachineryList_markerPopup(${JSON.stringify(a)})'>${a.sn||"--"}</div>
            </div>
          </li>
          <li>
            <div class="l">
           <div class="label">${u("work.companyName")}</div>
              <div class="value">${a.companyName||"--"}</div>
            </div>
            <div class="r">
              <div class="label">${u("messages.labelSN")}</div>
              <div class="value">${a.npn||"--"}</div>
            </div>
          </li>

          <li>
            <div class="l">
              <div class="label">${u("messages.workingcondition")}</div>
              <div class="value">
                <span class='${a.judgeLevel?"status "+l[a.judgeLevel]:""} '></span>
                <span>${a.judgeLevel||"--"}</span>
              </div>
            </div>
            <div class="r">
              <div class="label">${u("work.drivingStatus")}</div>
              <div class="value">
                <span class='${i[a.driveState]?"status "+e[a.driveState]:""}'></span>
                <span>${i[a.driveState]||"--"}</span>
              </div>
            </div>
          </li>
          <li>
            <div class="l">
              <div class="label">${u("work.solStat")}</div>
              <div class="value">
                <span class='${d[a.solStat]?a.solStat==4?"status status_3":"status status_0":""}'></span>
                <span>${d[a.solStat]||"--"}</span>
              </div>
            </div>
            <div class="r">
              <div class="label">${u("work.differentialChains")}</div>
              <div class="value">${v[a.diffSource]||"--"} (${a.diffAge!==null?a.diffAge+"s":"--"})</div>
            </div>
          </li>
          <li>
            <div class="l">
          <div class="label">${u("work.baseDis")}</div>
              <div class="value">${a.baseDist?(a.baseDist/1e3).toFixed(3)+"km":"--"}</div>
            </div>
            <div class="r">
               <div class="label">${u("work.terminalType")}</div>
              <div class="value">${a.terminalType||"--"}</div>
            </div>
          </li>

          <li>
            <div class="l">
              <div class="label">${u("work.lon")}</div>
              <div class="value">${V(a.posY)||"--"}</div>
            </div>
            <div class="r">
              <div class="label">${u("work.lat")}</div>
              <div class="value">${V(a.posX)||"--"}</div>

            </div>
          </li>
          <li>
            <div class="l">
               <div class="label">${u("work.CarStatus")}</div>
              <div class="value">${p}</div>
            </div>
            <div class="r">
              <div class="label"></div>
              <div class="value"></div>
            </div>
          </li>
        </ul>
        <ul class="btns_container">
          <li>
            <div class="btn ${c?"":"disabled"}" onclick='openRemote_markerPopup(${JSON.stringify(a)})'>${u("work.remoteManagement")}</div>
            <div class="btn" onclick='goTaskMachine_markerPopup(${JSON.stringify(a)})'>${u("devicelist.historyTrack")}</div>
          </li>
          <li>
            <div class="btn ${a.driveState==0||a.onlineTcp==0?"disabled":""}" onclick='openRealTimeChart_markerPopup(${JSON.stringify(a)})'>${u("messages.Realtimedrivingtrendchart")}</div>
            <div class="btn" onclick='gohistoryChart_markerPopup(${JSON.stringify(a)})'>${u("menus.historicaldrivingtrendchart")}</div>
          </li>
        </ul>
      </div>`}function b(a){const{terminalType:i,driveState:e,onlineTcp:l}=a;let d="";return l===0?d=de:d=e==0?se:ne,d}function P(a){const{terminalType:i,driveState:e}=a;let l="";return l=e==0?ce:Ae,l}function V(a){try{if(!a)return 0;let i=parseInt(a),e=(a-i)*60,l=parseInt(e),d=(e-l)*60;return`${i}\xB0${l}'${d.toFixed(3)}''`}catch(i){return console.log(i),a}}function $a(a){K.push({path:"/machineryList",query:{sn:a.sn}})}function ae(a){K.push({path:"/monitoring/taskMachine",query:{sn:a.sn,carId:a.carId}})}function ee(a){K.push({path:"/monitoring/historyChart",query:{sn:a.sn}})}function le(a){a.driveState==0||a.onlineTcp==0||(N.value=a.sn,O.value.dialogVisible=!0)}function ie(a){a.driveState==0&&(L.value=!L.value,X.value=a.terminalType,j.value=a.version,q.value=a.type,H.value=a.carId,N.value=a.sn,Q.value=a.carName)}return(a,i)=>{var k,y,Z,W,$,aa,ea,la,ia,ta;const e=I("Search"),l=I("el-icon"),d=I("el-autocomplete"),v=I("ArrowUpBold"),m=I("ArrowDownBold"),c=I("el-tooltip"),p=I("el-checkbox");return g(),h("div",ya,[f(oe,{ref_key:"sinoMapRef",ref:S,markerData:o(M),markerDataHandle:o(T),markerDataHidden:o(Y),mapCenter:C,mapRenderMode:"canvas"},null,8,["markerData","markerDataHandle","markerDataHidden","mapCenter"]),t("div",ga,[f(d,{style:Re({width:Ha.value}),modelValue:F.value,"onUpdate:modelValue":i[0]||(i[0]=n=>F.value=n),"fetch-suggestions":Qa,placeholder:a.$t("messages.SNLabelSNcarName"),onSelect:qa,clearable:""},{suffix:R(()=>[f(l,null,{default:R(()=>[f(e)]),_:1})]),default:R(({item:n})=>[t("div",{class:oa({bt_1:n.border&&n.markerId})},[n.markerId?(g(),h("div",fa,[t("span",null,s(n.sn),1),n.carName?(g(),h("span",ha," | "+s(n.carName),1)):D("",!0),n.npn?(g(),h("span",Sa," | "+s(n.npn),1)):D("",!0)])):D("",!0),n.markerId?(g(),h("div",ba,[t("span",null,s(n.companyName),1),n.tel?(g(),h("span",Ta," | "+s(n.tel),1)):D("",!0)])):D("",!0),n.markerId?D("",!0):(g(),h("div",wa,s(n),1))],2)]),_:1},8,["style","modelValue","placeholder"])]),t("div",{class:oa({statistics_box:!0,statistics_box_active:B.value})},[t("div",{class:"header",onClick:i[1]||(i[1]=n=>B.value=!B.value)},[B.value?(g(),sa(l,{key:1,color:"#fff"},{default:R(()=>[f(m)]),_:1})):(g(),sa(l,{key:0,color:"#fff"},{default:R(()=>[f(v)]),_:1}))]),t("ul",_a,[t("li",Ia,[t("div",null,s((k=o(r).device)==null?void 0:k.totalDevice),1),t("div",null,s(a.$t("messages.total")),1)]),t("li",Ra,[t("div",null,s((y=o(r).device)==null?void 0:y.onlineDevice),1),t("div",null,s(a.$t("messages.onlineCount")),1)]),t("li",Da,[t("div",null,s(((Z=o(r).device)==null?void 0:Z.totalDevice)-((W=o(r).device)==null?void 0:W.onlineDevice)),1),t("div",Ua,[na(s(a.$t("messages.Offline"))+" ",1),Ca])]),t("li",null,[t("div",null,s(($=o(r).workArea)==null?void 0:$.todayArea.toFixed(2)),1),t("div",null,s(a.$t("messages.todaysOperation")),1)]),t("li",null,[f(c,{class:"item",effect:"dark",disabled:J.value,content:((aa=o(r).workArea)==null?void 0:aa.totalArea)/1e4,placement:"top"},{default:R(()=>{var n;return[t("div",Ga,[t("span",{ref_key:"refName",ref:E,onMouseover:ja},s(o(r).workArea?(((n=o(r).workArea)==null?void 0:n.totalArea)/1e4).toFixed(2):""),545)])]}),_:1},8,["disabled","content"]),t("div",null,s(a.$t("messages.cumulativeOperation")),1)]),t("li",null,[t("div",null,s((ea=o(r).workDuration)==null?void 0:ea.todayDuration),1),t("div",null,s(a.$t("messages.todayTime"))+"(h)",1)]),t("li",null,[t("div",null,s(o(r).workArea?((la=o(r).workDuration)==null?void 0:la.beforeDuration).toFixed(2):""),1),t("div",null,s(a.$t("messages.culTime"))+"(h)",1)]),xa,t("li",Ba,[t("span",null,s((ia=o(r).drive)==null?void 0:ia.driving),1),t("div",null,[t("span",null,s(a.$t("messages.InOperation")),1),Na])]),t("li",Pa,[t("span",null,s((ta=o(r).drive)==null?void 0:ta.standbyDevice),1),t("div",null,[t("span",null,s(a.$t("messages.Standby")),1),Ea])])]),t("ul",Ka,[(g(!0),h(De,null,Ue(o(r).type,(n,te)=>(g(),h("li",{key:te},[t("label",null,[f(p,{size:"large",modelValue:n.checked,"onUpdate:modelValue":re=>n.checked=re,onChange:Wa},null,8,["modelValue","onUpdate:modelValue"]),t("span",Ma,s(n.typeName),1)]),t("span",Ja,s(n.onlineCount),1),na("/ "),t("span",La,s(n.totalCount),1)]))),128)),za])],2),f(ve,{ref_key:"realTime",ref:O,sn:o(N),socketData:o(x).socketData},null,8,["sn","socketData"]),f(pe,{isChange:o(L),terminalType:o(X),paramVersionnum:o(j),paramType:o(q),carId:o(H),sn:o(N),name:o(Q)},null,8,["isChange","terminalType","paramVersionnum","paramType","carId","sn","name"])])}}});da=xe(Ya,[["__scopeId","data-v-52238952"]])});export{Xe as __tla,da as default};
