! function(t) {
    var n = {};

    function i(a) {
        if (n[a]) return n[a].exports;
        var e = n[a] = {
            i: a,
            l: !1,
            exports: {}
        };
        return t[a].call(e.exports, e, e.exports, i), e.l = !0, e.exports
    }
    i.m = t, i.c = n, i.d = function(t, n, a) {
        i.o(t, n) || Object.defineProperty(t, n, {
            enumerable: !0,
            get: a
        })
    }, i.r = function(t) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(t, "__esModule", {
            value: !0
        })
    }, i.t = function(t, n) {
        if (1 & n && (t = i(t)), 8 & n) return t;
        if (4 & n && "object" == typeof t && t && t.__esModule) return t;
        var a = Object.create(null);
        if (i.r(a), Object.defineProperty(a, "default", {
            enumerable: !0,
            value: t
        }), 2 & n && "string" != typeof t)
            for (var e in t) i.d(a, e, function(n) {
                return t[n]
            }.bind(null, e));
        return a
    }, i.n = function(t) {
        var n = t && t.__esModule ? function() {
                return t.
                default
            } : function() {
                return t
            };
        return i.d(n, "a", n), n
    }, i.o = function(t, n) {
        return Object.prototype.hasOwnProperty.call(t, n)
    }, i.p = "", i(i.s = 0)
}([
    function(t, n, i) {
        var a = i(1),
            e = i(3);
        window.L.CanvasIconLayer = e(L), window.rbush = a
    },
    function(t, n, i) {
        "use strict";
        t.exports = e, t.exports.
        default = e;
        var a = i(2);

        function e(t, n) {
            if (!(this instanceof e)) return new e(t, n);
            this._maxEntries = Math.max(4, t || 9), this._minEntries = Math.max(2, Math.ceil(.4 * this._maxEntries)), n && this._initFormat(n), this.clear()
        }

        function r(t, n, i) {
            if (!i) return n.indexOf(t);
            for (var a = 0; a < n.length; a++)
                if (i(t, n[a])) return a;
            return -1
        }

        function o(t, n) {
            s(t, 0, t.children.length, n, t)
        }

        function s(t, n, i, a, e) {
            e || (e = p(null)), e.minX = 1 / 0, e.minY = 1 / 0, e.maxX = -1 / 0, e.maxY = -1 / 0;
            for (var r, o = n; o < i; o++) r = t.children[o], h(e, t.leaf ? a(r) : r);
            return e
        }

        function h(t, n) {
            return t.minX = Math.min(t.minX, n.minX), t.minY = Math.min(t.minY, n.minY), t.maxX = Math.max(t.maxX, n.maxX), t.maxY = Math.max(t.maxY, n.maxY), t
        }

        function l(t, n) {
            return t.minX - n.minX
        }

        function c(t, n) {
            return t.minY - n.minY
        }

        function u(t) {
            return (t.maxX - t.minX) * (t.maxY - t.minY)
        }

        function m(t) {
            return t.maxX - t.minX + (t.maxY - t.minY)
        }

        function f(t, n) {
            return t.minX <= n.minX && t.minY <= n.minY && n.maxX <= t.maxX && n.maxY <= t.maxY
        }

        function d(t, n) {
            return n.minX <= t.maxX && n.minY <= t.maxY && n.maxX >= t.minX && n.maxY >= t.minY
        }

        function p(t) {
            return {
                children: t,
                height: 1,
                leaf: !0,
                minX: 1 / 0,
                minY: 1 / 0,
                maxX: -1 / 0,
                maxY: -1 / 0
            }
        }

        function _(t, n, i, e, r) {
            for (var o, s = [n, i]; s.length;)(i = s.pop()) - (n = s.pop()) <= e || (o = n + Math.ceil((i - n) / e / 2) * e, a(t, o, n, i, r), s.push(n, o, o, i))
        }
        e.prototype = {
            all: function() {
                return this._all(this.data, [])
            },
            search: function(t) {
                var n = this.data,
                    i = [],
                    a = this.toBBox;
                if (!d(t, n)) return i;
                for (var e, r, o, s, h = []; n;) {
                    for (e = 0, r = n.children.length; e < r; e++) o = n.children[e], d(t, s = n.leaf ? a(o) : o) && (n.leaf ? i.push(o) : f(t, s) ? this._all(o, i) : h.push(o));
                    n = h.pop()
                }
                return i
            },
            collides: function(t) {
                var n = this.data,
                    i = this.toBBox;
                if (!d(t, n)) return !1;
                for (var a, e, r, o, s = []; n;) {
                    for (a = 0, e = n.children.length; a < e; a++)
                        if (r = n.children[a], d(t, o = n.leaf ? i(r) : r)) {
                            if (n.leaf || f(t, o)) return !0;
                            s.push(r)
                        }
                    n = s.pop()
                }
                return !1
            },
            load: function(t) {
                if (!t || !t.length) return this;
                if (t.length < this._minEntries) {
                    for (var n = 0, i = t.length; n < i; n++) this.insert(t[n]);
                    return this
                }
                var a = this._build(t.slice(), 0, t.length - 1, 0);
                if (this.data.children.length)
                    if (this.data.height === a.height) this._splitRoot(this.data, a);
                    else {
                        if (this.data.height < a.height) {
                            var e = this.data;
                            this.data = a, a = e
                        }
                        this._insert(a, this.data.height - a.height - 1, !0)
                    } else this.data = a;
                return this
            },
            insert: function(t) {
                return t && this._insert(t, this.data.height - 1), this
            },
            clear: function() {
                return this.data = p([]), this
            },
            remove: function(t, n) {
                if (!t) return this;
                for (var i, a, e, o, s = this.data, h = this.toBBox(t), l = [], c = []; s || l.length;) {
                    if (s || (s = l.pop(), a = l[l.length - 1], i = c.pop(), o = !0), s.leaf && -1 !== (e = r(t, s.children, n))) return s.children.splice(e, 1), l.push(s), this._condense(l), this;
                    o || s.leaf || !f(s, h) ? a ? (i++, s = a.children[i], o = !1) : s = null : (l.push(s), c.push(i), i = 0, a = s, s = s.children[0])
                }
                return this
            },
            toBBox: function(t) {
                return t
            },
            compareMinX: l,
            compareMinY: c,
            toJSON: function() {
                return this.data
            },
            fromJSON: function(t) {
                return this.data = t, this
            },
            _all: function(t, n) {
                for (var i = []; t;) t.leaf ? n.push.apply(n, t.children) : i.push.apply(i, t.children), t = i.pop();
                return n
            },
            _build: function(t, n, i, a) {
                var e, r = i - n + 1,
                    s = this._maxEntries;
                if (r <= s) return o(e = p(t.slice(n, i + 1)), this.toBBox), e;
                a || (a = Math.ceil(Math.log(r) / Math.log(s)), s = Math.ceil(r / Math.pow(s, a - 1))), (e = p([])).leaf = !1, e.height = a;
                var h, l, c, u, m = Math.ceil(r / s),
                    f = m * Math.ceil(Math.sqrt(s));
                for (_(t, n, i, f, this.compareMinX), h = n; h <= i; h += f)
                    for (_(t, h, c = Math.min(h + f - 1, i), m, this.compareMinY), l = h; l <= c; l += m) u = Math.min(l + m - 1, c), e.children.push(this._build(t, l, u, a - 1));
                return o(e, this.toBBox), e
            },
            _chooseSubtree: function(t, n, i, a) {
                for (var e, r, o, s, h, l, c, m, f, d; a.push(n), !n.leaf && a.length - 1 !== i;) {
                    for (c = m = 1 / 0, e = 0, r = n.children.length; e < r; e++) h = u(o = n.children[e]), f = t, d = o, (l = (Math.max(d.maxX, f.maxX) - Math.min(d.minX, f.minX)) * (Math.max(d.maxY, f.maxY) - Math.min(d.minY, f.minY)) - h) < m ? (m = l, c = h < c ? h : c, s = o) : l === m && h < c && (c = h, s = o);
                    n = s || n.children[0]
                }
                return n
            },
            _insert: function(t, n, i) {
                var a = this.toBBox,
                    e = i ? t : a(t),
                    r = [],
                    o = this._chooseSubtree(e, this.data, n, r);
                for (o.children.push(t), h(o, e); n >= 0 && r[n].children.length > this._maxEntries;) this._split(r, n), n--;
                this._adjustParentBBoxes(e, r, n)
            },
            _split: function(t, n) {
                var i = t[n],
                    a = i.children.length,
                    e = this._minEntries;
                this._chooseSplitAxis(i, e, a);
                var r = this._chooseSplitIndex(i, e, a),
                    s = p(i.children.splice(r, i.children.length - r));
                s.height = i.height, s.leaf = i.leaf, o(i, this.toBBox), o(s, this.toBBox), n ? t[n - 1].children.push(s) : this._splitRoot(i, s)
            },
            _splitRoot: function(t, n) {
                this.data = p([t, n]), this.data.height = t.height + 1, this.data.leaf = !1, o(this.data, this.toBBox)
            },
            _chooseSplitIndex: function(t, n, i) {
                var a, e, r, o, h, l, c, m, f, d, p, _, g, x;
                for (l = c = 1 / 0, a = n; a <= i - n; a++) e = s(t, 0, a, this.toBBox), r = s(t, a, i, this.toBBox), f = e, d = r, void 0, void 0, void 0, void 0, p = Math.max(f.minX, d.minX), _ = Math.max(f.minY, d.minY), g = Math.min(f.maxX, d.maxX), x = Math.min(f.maxY, d.maxY), o = Math.max(0, g - p) * Math.max(0, x - _), h = u(e) + u(r), o < l ? (l = o, m = a, c = h < c ? h : c) : o === l && h < c && (c = h, m = a);
                return m
            },
            _chooseSplitAxis: function(t, n, i) {
                var a = t.leaf ? this.compareMinX : l,
                    e = t.leaf ? this.compareMinY : c;
                this._allDistMargin(t, n, i, a) < this._allDistMargin(t, n, i, e) && t.children.sort(a)
            },
            _allDistMargin: function(t, n, i, a) {
                t.children.sort(a);
                var e, r, o = this.toBBox,
                    l = s(t, 0, n, o),
                    c = s(t, i - n, i, o),
                    u = m(l) + m(c);
                for (e = n; e < i - n; e++) r = t.children[e], h(l, t.leaf ? o(r) : r), u += m(l);
                for (e = i - n - 1; e >= n; e--) r = t.children[e], h(c, t.leaf ? o(r) : r), u += m(c);
                return u
            },
            _adjustParentBBoxes: function(t, n, i) {
                for (var a = i; a >= 0; a--) h(n[a], t)
            },
            _condense: function(t) {
                for (var n, i = t.length - 1; i >= 0; i--) 0 === t[i].children.length ? i > 0 ? (n = t[i - 1].children).splice(n.indexOf(t[i]), 1) : this.clear() : o(t[i], this.toBBox)
            },
            _initFormat: function(t) {
                var n = ["return a", " - b", ";"];
                this.compareMinX = new Function("a", "b", n.join(t[0])), this.compareMinY = new Function("a", "b", n.join(t[1])), this.toBBox = new Function("a", "return {minX: a" + t[0] + ", minY: a" + t[1] + ", maxX: a" + t[2] + ", maxY: a" + t[3] + "};")
            }
        }
    },
    function(t, n, i) {
        t.exports = function() {
            "use strict";

            function t(t, n, i) {
                var a = t[n];
                t[n] = t[i], t[i] = a
            }

            function n(t, n) {
                return t < n ? -1 : t > n ? 1 : 0
            }
            return function(i, a, e, r, o) {
                ! function n(i, a, e, r, o) {
                    for (; r > e;) {
                        if (r - e > 600) {
                            var s = r - e + 1,
                                h = a - e + 1,
                                l = Math.log(s),
                                c = .5 * Math.exp(2 * l / 3),
                                u = .5 * Math.sqrt(l * c * (s - c) / s) * (h - s / 2 < 0 ? -1 : 1),
                                m = Math.max(e, Math.floor(a - h * c / s + u)),
                                f = Math.min(r, Math.floor(a + (s - h) * c / s + u));
                            n(i, a, m, f, o)
                        }
                        var d = i[a],
                            p = e,
                            _ = r;
                        for (t(i, e, a), o(i[r], d) > 0 && t(i, e, r); p < _;) {
                            for (t(i, p, _), p++, _--; o(i[p], d) < 0;) p++;
                            for (; o(i[_], d) > 0;) _--
                        }
                        0 === o(i[e], d) ? t(i, e, _) : t(i, ++_, r), _ <= a && (e = _ + 1), a <= _ && (r = _ - 1)
                    }
                }(i, a, e || 0, r || i.length - 1, o || n)
            }
        }()
    },
    function(t, n, i) {
        "use strict";
        t.exports = function(t) {
            var n = (t.Layer ? t.Layer : t.Class).extend({
                initialize: function(n) {
                    t.setOptions(this, n), this._onClickListeners = [], this._onHoverListeners = []
                },
                setOptions: function(n) {
                    return t.setOptions(this, n), this.redraw()
                },
                redraw: function() {
                    this._redraw(!0)
                },
                addMarkers: function(t) {
                    var n = this,
                        i = [],
                        a = [];
                    t.forEach(function(t) {
                        if ("markerPane" == t.options.pane && t.options.icon) {
                            var e = t.getLatLng(),
                                r = n._map.getBounds().contains(e),
                                o = n._addMarker(t, e, r);
                            !0 === r && i.push(o[0]), a.push(o[1])
                        } else {
                            console.error("Layer isn't a marker")
                            }
                    }), n._markers.load(i), n._latlngMarkers.load(a)
                },
                addMarker: function(t) {
                    var n = t.getLatLng(),
                        i = this._map.getBounds().contains(n),
                        a = this._addMarker(t, n, i);
                    !0 === i && this._markers.insert(a[0]), this._latlngMarkers.insert(a[1])
                },
                addLayer: function(t) {
                    "markerPane" == t.options.pane && t.options.icon ? this.addMarker(t) : console.error("Layer isn't a marker")
                },
                addLayers: function(t) {
                    this.addMarkers(t)
                },
                removeLayer: function(t) {
                    this.removeMarker(t, !0)
                },
                removeMarker: function(t, n) {
                    t.minX && (t = t.data);
                    var i = t.getLatLng(),
                        a = this._map.getBounds().contains(i),
                        e = {
                            minX: i.lng,
                            minY: i.lat,
                            maxX: i.lng,
                            maxY: i.lat,
                            data: t
                        };
                    this._latlngMarkers.remove(e, function(t, n) {
                        return t.data._leaflet_id === n.data._leaflet_id
                    }), this._latlngMarkers.total--, this._latlngMarkers.dirty++, !0 === a && !0 === n && this._redraw(!0)
                },
                // onAdd: function(t) {
                //     this._map = t, this._canvas || this._initCanvas(), this.options.pane ? this.getPane().appendChild(this._canvas) : t._panes.overlayPane.appendChild(this._canvas), t.on("moveend", this._reset, this), t.on("resize", this._reset, this), t.on("click", this._executeListeners, this), t.on("mousemove", this._executeListeners, this)
                // },
                onAdd: function (map) {

                    this._map = map;
        
                    if (!this._canvas) this._initCanvas();
        
                    if (this.options.pane) this.getPane().appendChild(this._canvas);
                    else map._panes.overlayPane.appendChild(this._canvas);
        
                    map.on('moveend', this._reset, this);
                    map.on('resize',this._reset,this);
        
                    map.on('click', this._executeListeners, this);
                    map.on('mousemove', this._executeListeners, this);
                    // map.on('mousemove', ()=>{this._executeListeners();this._animateZoom()}, this);
                    if (map._zoomAnimated) {
                        map.on('zoomanim', this._animateZoom, this);
                    }
                },
                onRemove: function(t) {
                    this.options.pane ? this.getPane().removeChild(this._canvas) : t.getPanes().overlayPane.removeChild(this._canvas)
                    this._map.removeEventListener('mousemove');
                    this._map.removeEventListener('moveend');
                    this._map.removeEventListener('click');
                    this._map.removeEventListener('resize');
                    if (t._zoomAnimated) {
                        this._map.removeEventListener('zoomanim');
                    }
                },
                _animateZoom: function(event) {
                    var scale = this._map.getZoomScale(event.zoom);
                    var offset = this._map._latLngBoundsToNewLayerBounds(this._map.getBounds(), event.zoom, event.center).min;
        
                    L.DomUtil.setTransform(this._canvas, offset, scale);
                },
                addTo: function(t) {
                    return t.addLayer(this), this
                },
                _addMarker: function(n, i, a) {
                    n._map = this._map, this._markers || (this._markers = new rbush), this._latlngMarkers || (this._latlngMarkers = new rbush, this._latlngMarkers.dirty = 0, this._latlngMarkers.total = 0), t.Util.stamp(n);
                    var e = this._map.latLngToContainerPoint(i),
                        r = n.options.icon.options.iconSize,
                        o = r[0] / 2,
                        s = r[1] / 2,
                        h = [{
                            minX: e.x - o,
                            minY: e.y - s,
                            maxX: e.x + o,
                            maxY: e.y + s,
                            data: n
                        }, {
                            minX: i.lng,
                            minY: i.lat,
                            maxX: i.lng,
                            maxY: i.lat,
                            data: n
                        }];
                      
                    return this._latlngMarkers.dirty++, this._latlngMarkers.total++, !0 === a && this._drawMarker(n, e), h
                },
                _drawMarker: function(t, n) {
                    var i = this;
                    this._imageLookup || (this._imageLookup = {}), n || (n = i._map.latLngToContainerPoint(t.getLatLng()));
                    var a = t.options.icon.options.iconUrl;
                    var label=t.options.icon.options.html;
                    if(a!=undefined){
                        if (t.canvas_img) i._drawImage(t, n);
                        else if (i._imageLookup[a]) t.canvas_img = i._imageLookup[a][0], !1 === i._imageLookup[a][1] ? i._imageLookup[a][2].push([t, n]) : i._drawImage(t, n);
                        else {
                            var e = new Image;
                            e.src = a, t.canvas_img = e, i._imageLookup[a] = [e, !1, [
                                [t, n]
                            ]], e.onload = function() {
                                i._imageLookup[a][1] = !0, i._imageLookup[a][2].forEach(function(t) {
                                    i._drawImage(t[0], t[1])
                                })
                            }
                        }
                    }else if(label!=undefined){
                        if (t.canvas_label) i._drawLabel(t, n);
                        else if (i._imageLookup[label]) t.canvas_label = i._imageLookup[label][0], !1 === i._imageLookup[label][1] ? i._imageLookup[label][2].push([t, n]) : i._drawLabel(t, n);
                        else {
                          
                             t.canvas_label = label, i._imageLookup[label] = [label, !1, [
                                [t, n]
                            ]];
                            i._imageLookup[label][1] = !0, i._imageLookup[label][2].forEach(function(t) {
                                i._drawLabel(t[0], t[1])
                            })
                        }
                    }
                    
                   
                },
                _drawImage: function(t, n) {
                    var i = t.options.icon.options;
                    this._context.drawImage(t.canvas_img, n.x - i.iconAnchor[0], n.y - i.iconAnchor[1], i.iconSize[0], i.iconSize[1])
                },
                _drawLabel: function(t, n) {
                    var i = t.options.icon.options;
                    this._context.font=i.font;
                    this._context.fillStyle=i.fillStyle;
                    this._context.fillText(t.canvas_label, n.x - i.textAnchor[0], n.y - i.textAnchor[1])
                    //this._context.fillText(t.canvas_label, n.x - 0, n.y - 0)
                },
                _reset: function() {
                    var n = this._map.containerPointToLayerPoint([0, 0]);
                    t.DomUtil.setPosition(this._canvas, n);
                    var i = this._map.getSize();
                    this._canvas.width = i.x, this._canvas.height = i.y, this._redraw()
                },
                _redraw: function(t) {
                    var n = this;
                    if (this._map&&this._latlngMarkers) {
                        t && this._context.clearRect(0, 0, this._canvas.width, this._canvas.height);
                        var i = [];
                        n._latlngMarkers.dirty / n._latlngMarkers.total >= .1 && (n._latlngMarkers.all().forEach(function(t) {
                            i.push(t)
                        }), n._latlngMarkers.clear(), n._latlngMarkers.load(i), n._latlngMarkers.dirty = 0, i = []);
                        var a = n._map.getBounds(),
                            e = {
                                minX: a.getWest(),
                                minY: a.getSouth(),
                                maxX: a.getEast(),
                                maxY: a.getNorth()
                            };
                        n._latlngMarkers.search(e).forEach(function(t) {
                            var a = n._map.latLngToContainerPoint(t.data.getLatLng()),
                                e = t.data.options.icon.options.iconSize,
                                r = e[0] / 2,
                                o = e[1] / 2,
                                s = {
                                    minX: a.x - r,
                                    minY: a.y - o,
                                    maxX: a.x + r,
                                    maxY: a.y + o,
                                    data: t.data
                                };
                            i.push(s), n._drawMarker(t.data, a)
                        }), this._markers.clear(), this._markers.load(i)
                    }
                },
                _initCanvas: function() {
                    this._canvas = t.DomUtil.create("canvas", "leaflet-canvas-icon-layer leaflet-layer");
                    // var n = t.DomUtil.testProp(["transformOrigin", "WebkitTransformOrigin", "msTransformOrigin"]);
                    // this._canvas.style[n] = "50% 50%";
                    var i = this._map.getSize();
                    this._canvas.width = i.x, this._canvas.height = i.y, this._context = this._canvas.getContext("2d");
                    var a = this._map.options.zoomAnimation && t.Browser.any3d;
                    t.DomUtil.addClass(this._canvas, "leaflet-zoom-" + (a ? "animated" : "hide"))
                },
                addOnClickListener: function(t) {
                    this._onClickListeners.push(t)
                },
                addOnHoverListener: function(t) {
                    this._onHoverListeners.push(t)
                },
                _executeListeners: function(t) {
                    var n = this,
                        i = t.containerPoint.x,
                        a = t.containerPoint.y;
                    n._openToolTip && (n._openToolTip.closeTooltip(), delete n._openToolTip);
                   if(this._markers!=undefined){
                    var e = this._markers.search({
                        minX: i,
                        minY: a,
                        maxX: i,
                        maxY: a
                    });
                  
                    e && e.length > 0 ? (n._map._container.style.cursor = "pointer", "click" === t.type && (e[0].data.getPopup() && e[0].data.openPopup(), n._onClickListeners.forEach(function(n) {
                        n(t, e)
                    })), "mousemove" === t.type && (e[0].data.getTooltip() && (n._openToolTip = e[0].data, e[0].data.openTooltip()), n._onHoverListeners.forEach(function(n) {
                        n(t, e)
                    }))) : n._map._container.style.cursor = ""
                   }
                   
                }
            });
            t.canvasIconLayer = function(t) {
                return new n(t)
            }
        }
    }
]);