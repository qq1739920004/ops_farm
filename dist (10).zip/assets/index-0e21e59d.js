import{A as te,a as se}from"./AG360_warn-40300f8f.js";import{S as ne,A as oe,y as de,g as ce,__tla as ue}from"./index-03109e91.js";import Ae,{__tla as ve}from"./realTimeChart-afa1faed.js";import{_ as me,__tla as pe}from"./index.vue_vue_type_script_setup_true_lang-d96bed42.js";import{s as ke,__tla as ge}from"./socket-93e18146.js";import{d as ye,r as u,g as ta,A as he,x as fe,y as Te,B as _e,C as Ie,a as Se,o as Ce,h as b,c as f,k as h,u as o,j as r,w,D as be,b as sa,t as s,p as na,F as we,q as Ne,G as oa,H as De,I as Me,f as y,e as N,_ as Ee,__tla as Re}from"./index-5b8ebcf5.js";import{f as Ye,o as Je,__tla as xe}from"./index-fced7bdf.js";import"./gcoord.esm-bundler-25b3e209.js";import"./index-9a6536ad.js";import{__tla as Be}from"./remoteAdjust-de15ae4a.js";import{__tla as Le}from"./index-92ccee69.js";import{__tla as Qe}from"./index-ea3b9a73.js";import{__tla as Ue}from"./remoteAdjust302-39f092f0.js";import{__tla as $e}from"./remoteAdjust502-8698683a.js";import{__tla as Fe}from"./remoteAdjust501Pro-d3187888.js";import{__tla as Oe}from"./remoteAdjust360-6670f52a.js";let da,Ge=Promise.all([(()=>{try{return ue}catch{}})(),(()=>{try{return ve}catch{}})(),(()=>{try{return pe}catch{}})(),(()=>{try{return ge}catch{}})(),(()=>{try{return Re}catch{}})(),(()=>{try{return xe}catch{}})(),(()=>{try{return Be}catch{}})(),(()=>{try{return Le}catch{}})(),(()=>{try{return Qe}catch{}})(),(()=>{try{return Ue}catch{}})(),(()=>{try{return $e}catch{}})(),(()=>{try{return Fe}catch{}})(),(()=>{try{return Oe}catch{}})()]).then(async()=>{const ca="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAAAXNSR0IArs4c6QAAA5xJREFUWEftmO1RFEEQhrsz0AwgAiUCMQIlArkIlAiECNQIPCIQIxAi4IhAMpAM2nm3urd6e3t25riCuh9sFXXc7s7MM/3xTvcx7fnFe85HL4C7eujZLCgin4jolIh+MPNVL/izACrc2kGdMvNlD+STA4rIRyL6lcB0QT4KUEQOmPm+ZQEReUtEf4jolb57RkRwNe7jakJuDSgiX8vM52VyAL6vgSZwK2ZeiwhgAd0FuRWggzPjpZA1OBu0DWQ3YIAD2IEuOIGE+4no1rl1sFwMhwTyJMvuLsAAt4FriegLEcHduEbIsvB3Ivqs9x+I6GghDI7V3Xgd8oM5J1cTMIMrE2FhCjADZAHHMx9jPWFQjedFwCARg+UcHFxpGWpZ2gUZYnQx2VqA3gXejR4OVoPWTdytMYoNTBJKY9M2tgiHgT0uxvH008XaSr/DarAoLAt3Q3o8JJ6bZT2k3W/CdQHq4h4StxBnI5yTDw9p72FD31zWT5IqJsXWSeIWj5ZMRTpY8oqZT1R64FaERpSlITyY+SiDbbrYDxKRx0CumXmlkIAB9HhMiojF+QUzwwPbyUwcsAtkzZ0iMsgSM7/eGTCJyZrO+RNlU3NhmA9hc+0hu1ys7kEmY1EcSZslS4aYmySUaiCSBi4dYPTY+5edJk3AsNiYwQrr6zwTaatW8DnLdoX5W1TgpmwUMTlcpajFvXtmhq6OV0uoTZDxicVM1/A//uJ9QJrOpVKkMEMxUarqQweYxmEVMJMGIkLGmWjb3ChCAWUiPVrZRDxJtBrgMZdUblqwEUNeakYrOf2rWi7E27V3Zy2TZxZcgquItoeEhZGxQ7WTXS65JnWiiCBJMHY5BjVYrRhNi8hEagB0uASmYyym8XU8iZxYz2rCzILYiSXDeYmJi4olrDexxwCsNlLBM2fMjMLWMhhqgIyezZEBxk5sBpn0ueMxpTqHREKVc6fZ/kabdmw8wllbOhyJ0RhpFidNzwi5BKduxAYBaF2bZTV+TcBG/Dns68q0NViSmZklS3/xWxsi22h6wLtsNZ18iPEZmqaJVZsy42IjQnqx9m6F6FYzN9FBgCPuMH91kxjXc9RFSIzzcFYuobW8jIe9h1OroeOz7g3zjMmSJWMT0MWV9RGTHeui1pNYQYp4u3HHIZLjg55EmBJFAnSw+fNJF6DTMLhy6EEq0gNrA/adus93exgH6EnBWpvL7ncDtiZ6qucvgLtadu8t+B8MoClHpWe61AAAAABJRU5ErkJggg==",ua="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAAAINJREFUWEftlMENgDAMA+0h2AcmgykYgiUoSzAESxiKhARVqXjRj/OMEsU6xSYqFyvfhwWYgAmYgAmcBCS1SSRvJNc/YpqShkNDnxwLJDsLMIHqBCRNAJq7kOs5Jc1f+gAWkvHRo9seOwDGog0z9gTJkLPuWz/OlnachCZgAiZgAiawA8M5SXPGNTTVAAAAAElFTkSuQmCC",Aa="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAAALlJREFUWEftldENwjAMRO+GYIlO0cyA6BAwBLAEQ5QhaIeAMVjhqJGQKiuFn6gRkvMXJ4pfXiyHqDxYOT8CIAyEgTDw1YCkHsDGNasDyUepBvYLQJlEieQQADUNtCTHYgBToTUAOnfgneRVUq4GigOcABwdwDDdMq0FYMkNYj5WBahu4D8BJLXzN/s0Jx+3PUtrFqekHYB9pgbOC614S/Ip6eYAks19HMBI8l1jmbVL/IZhIAyEgTDwAmlFeHPch8y3AAAAAElFTkSuQmCC",va="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAAAMhJREFUWEftlssNwjAQRGc64QxNQBGkCJog9cCBEgglcOBMKUM24oBWTqRYkSOZ9dGJs5Pn2Q+x8uLK8RECgkAWAUlHADtn4BfJ61xT5wq4A9i7YB3JQwgIAnURkOSdDpKdpDJZIOkNYOOwWqqdi6ShJCXuNARURuDbWE7urh8k2yIe6IOYo9tUY/kbAfb3RuF3Da21FIG6BPS1y/vJyvewl3h2oaQtgCY1Xo19bGQke5K8uTNWSTkpYG77XPr9rJlwSREhIAh8AHRhq29pwmW7AAAAAElFTkSuQmCC",ma="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAAAN5JREFUWEftl7ENwjAQRf8fAoaADWggDRvAEDAEZAgYggxBKiaAKdiA5hNLLsIpaaLIlsK5jZz7en4nn4nMi5nrY1oBJC0AXAzVN8l9H+lRCUjaALjbYiR763gAJzCIgKQtgJWR7QHgk0RCScH0YHx71QBKD+AEnMCoBCQ9ASxNuxUATknaUJI6rlEPMDECcYyyI9OLZJXEgcazc7T652IhWaQKEFoqhMgWIDuB/wgQZZ+3z5lkTUk7AIcOB8pm0615aMzMtyOAsKdrIqr6HiZR9rX513XQTDjme9IDfAHAzclzRlgFYQAAAABJRU5ErkJggg==",pa="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAAAMlJREFUWEftl9ENwjAQQ+052ACGgA5B16Fdpx2CMAQrsIbJSfkoUfIBioJU3X22iuy++nIJ0akkXQGcMrmFnfQh6Q7gkunNbmB/BCTl/xkkQ5cMJHEL27ZeJA//NGAE6AacQFMCkiYA5yztj7jVhvg874L2Iax8jYnPbsAJ7IvAl5OtfRcoNnzhyDYAuBWOV27ACfxGIAbNAmXDZVsrybFLCNNkMxPbCiQHN+AEehE4AhizED5JrimgH69ITpWrdmmNbeV2LaitWd7I5F4koTCKbQAAAABJRU5ErkJggg==",D=E=>(De("data-v-2edc4b4c"),E=E(),Me(),E),ka={class:"map_container"},ga={class:"search_box"},ya={key:0},ha={key:0},fa={key:1},Ta={key:1},_a={key:0},Ia={key:2},Sa={class:"top"},Ca={class:"top_line"},ba={class:"top_line"},wa={class:"top_line"},Na={class:"outside"},Da=D(()=>r("div",{class:"offline_area"},null,-1)),Ma={style:{"text-overflow":"ellipsis",overflow:"hidden"}},Ea=D(()=>r("div",{style:{height:"2px",width:"100%","background-color":"rgba(0, 218, 216, 0.3)",margin:"15px 0"}},null,-1)),Ra={class:"bottom_li"},Ya=D(()=>r("div",null,null,-1)),Ja={class:"bottom_li"},xa=D(()=>r("div",null,null,-1)),Ba={class:"center"},La={class:"label"},Qa={class:"value"},Ua={class:"value"},$a=D(()=>r("br",null,null,-1)),Fa=ye({__name:"index",setup(E){const T=u(),{t:A}=ta(),{locale:Oa}=ta(),B=u(null);let Ga=500;const L=he(),F=fe(),R=ke();let Q=u([]),O=u([]),I=u({}),t=u({});const U=u(!0),Y=u(!1);let J=u(),G=u(),W=u(),H=u(),X=u(),P=u(),Z=u(),$=u(!1);const V=u(""),M=Te({markerId:"",mapCenter:[]});window.goMachineryList_markerPopup=za,window.goTaskMachine_markerPopup=Ka,window.gohistoryChart_markerPopup=ae,window.openRealTimeChart_markerPopup=ee,window.openRemote_markerPopup=le,_e(()=>R.socketData,a=>{Za(a)},{deep:!0});function Wa(){let a=B.value.parentNode.offsetWidth;B.value.offsetWidth>a?U.value=!1:U.value=!0}const Ha=Ie(()=>Oa.value=="zh"?"280px":"350px");Se(()=>{R.close()}),Ce(()=>{R.connect()}),Va(),ja();function Xa(a,i){let e=Q.value.filter(l=>{if(l.sn&&l.sn.includes(a)||l.npn&&l.npn.includes(a)||l.carName&&l.carName.includes(a)||l.companyName&&l.companyName.includes(a)||l.tel&&l.tel.includes(a))return!0});if(e.length<=0){i(["\u65E0\u6570\u636E"]);return}e.length>3&&(e.length=3),e.forEach(l=>{l.border=!0,l.value=l.sn}),e[e.length-1].border=!1,i(e)}function Pa(a){a.markerId&&(M.markerId="",M.markerId=a.markerId)}function Za(a){if(a.module=="farm"&&a.type=="farmPt"){let{action:i,data:e}=a;if(i=="upline")if(T.value.isIconChange){const l=e.sn,d=e.posY,v=e.posX,m=e.onlineTcp,c=e.driveState,p=S(e),k=T.value.iconChangeLimit?_(e):x(e),g=C(e);I.value={markerId:l,onlineTcp:m,driveState:c,markerLng:d,markerLat:v,markerType:p,markerIcon:k,markerPopup:g,markerHandle:"add"}}else{const l=e.sn,d=e.posY,v=e.posX,m=S(e),c=_(e),p=C(e),k=e.onlineTcp,g=e.driveState;I.value={markerId:l,onlineTcp:k,driveState:g,markerLng:d,markerLat:v,markerType:m,markerIcon:c,markerPopup:p,markerHandle:"add"}}if(i=="offline")if(T.value.isIconChange){const l=e.sn,d=e.posY,v=e.posX,m=e.onlineTcp,c=e.driveState,p=S(e),k=T.value.iconChangeLimit?_(e):x(e),g=C(e);I.value={markerId:l,onlineTcp:m,driveState:c,markerLng:d,markerLat:v,markerType:p,markerIcon:k,markerPopup:g,markerHandle:"delete"}}else{const l=e.sn,d=e.posY,v=e.posX,m=S(e),c=_(e),p=C(e),k=e.onlineTcp,g=e.driveState;I.value={markerId:l,onlineTcp:k,driveState:g,markerLng:d,markerLat:v,markerType:m,markerIcon:c,markerPopup:p,markerHandle:"delete"}}if(i=="online")if(T.value.isIconChange){const l=T.value.iconChangeLimit?_(e):x(e),d=e.sn,v=e.posY,m=e.onlineTcp,c=e.driveState,p=e.posX,k=S(e),g=C(e);I.value={markerId:d,markerLng:v,markerLat:p,onlineTcp:m,driveState:c,markerType:k,markerIcon:l,markerPopup:g,markerHandle:"update"}}else{const l=_(e),d=e.sn,v=e.posY,m=e.posX,c=e.onlineTcp,p=e.driveState,k=S(e),g=C(e);I.value={markerId:d,markerLng:v,markerLat:m,onlineTcp:c,driveState:p,markerType:k,markerIcon:l,markerPopup:g,markerHandle:"update"}}}if(a.module=="farm"&&a.type=="monitor"){const{data:i}=a;t.value.device.totalDevice=i.totalDevice,t.value.device.onlineDevice=i.onlineDevice,t.value.drive.driving=i.driving,t.value.drive.standbyDevice=i.standbyDevice;const e=i.typeCounts;t.value.type.forEach((l,d)=>{l.onlineCount=e[d].onlineCount,l.totalCount=e[d].totalCount})}if(a.module=="farm"&&a.type=="monitorArea"){const{data:i}=a;t.value.workArea.todayArea=i.todayArea,t.value.workArea.totalArea=i.totalArea,t.value.workDuration.todayDuration=i.todayDuration,t.value.workDuration.beforeDuration=i.beforeDuration}if(a.module=="farm"&&a.type=="monitorCarNum"){const{data:i}=a;t.value.drive.driving=i.driving,t.value.drive.standbyDevice=i.standbyDevice,t.value.device.onlineDevice=i.driving+i.standbyDevice}}async function Va(){const{data:a}=await Ye();t.value=a,t.value.type.forEach(i=>i.checked=!0)}async function ja(){const{data:a}=await Je({});let i=a.onlineFarmMachines,e=[];i.map(l=>{l.posX!==null&&e.push(l)}),i.forEach(l=>{l.markerId=l.sn,l.markerLng=l.posY,l.markerLat=l.posX,l.markerType=S(l),e.length>Ga?T.value.iconChangeLimit?l.markerIcon=_(l):l.markerIcon=x(l):l.markerIcon=_(l),l.markerPopup=C(l),l.driveState=l.driveState}),i=i.filter(l=>l.markerLng||l.markerLng==0),Q.value=i,F.query.markerId&&(M.markerId=F.query.markerId),M.center=i.map(l=>[l.posY,l.posX])}function qa(){let a=t.value.type.filter(i=>!i.checked);a=a.map(i=>i.typeName),O.value=a}function S(a){return a.terminalType&&a.terminalType.includes("AG360")?"AG360":a.terminalType&&a.terminalType.includes("AG501")&&a.terminalType!="AG501Pro"?"AG501":a.terminalType&&a.terminalType=="AG501Pro"?"AG501Pro":a.terminalType&&a.terminalType.includes("AG502")?"AG502":a.terminalType&&a.terminalType.includes("AG302")&&a.terminalType!="AG302Android"?"AG302":a.terminalType&&a.terminalType=="AG302Android"?"AG302Android":a.terminalType&&a.terminalType.includes("MC100")?"MC100":a.terminalType&&a.terminalType.includes("SA200")?"SA200":a.terminalType&&a.terminalType.includes("MT801")?"MT801Pro":a.terminalType&&a.terminalType.includes("MT802")?"MT802":""}function C(a){const i={0:"\u975E\u81EA\u52A8\u9A7E\u9A76",1:"\u81EA\u52A8\u9A7E\u9A76",2:"\u81EA\u52A8\u9A7E\u9A76"},e={0:"status_1",1:"status_2",2:"status_3",null:"status_1"},l={\u4F18:"status_3",\u4E2D:"status_2",\u5DEE:"status_0",null:"status_1"},d={0:"\u65E0\u6548\u89E3",1:"\u5355\u70B9\u89E3",2:"\u5DEE\u5206\u89E3",3:"\u6D6E\u52A8\u89E3",4:"\u56FA\u5B9A\u89E3"},v={0:"\u7535\u53F0",1:"\u7F51\u7EDC",3:"\u7F57\u7F51"},m={0:ua,1:Aa,2:va,3:ma,4:pa};let c=!0;a.onlineTcp===0||a.driveState!=0?c=!1:c=!0;const p=a.cardUsage==1?"\u53611":a.cardUsage==2?"\u53612":"\u53CC\u5361";return`<div class="map_popup">

        <ul class="popup_container">
         <li>
            <div class="le">
              <span > <img class="sate" src=${ca}></span>
             <span class="value">${a.satNum||"--"}</span>
            </div>
            <div class="re" >
              <div class="value" style="margin-left: auto;margin-right:20px">
                <img src=${m[a.netSignal]}>
                <span>4G</span>
              </div>
            </div>
          </li>
          <li>
            <div class="l">
              <div class="label">${A("messages.carName")}</div>
              <div class="value">${a.carName||"--"}</div>
            </div>
            <div class="r">
              <div class="label">SN</div>
              <div class="value"  style="cursor: pointer;text-decoration: underline;" onclick='goMachineryList_markerPopup(${JSON.stringify(a)})'>${a.sn||"--"}</div>
            </div>
          </li>
          <li>
            <div class="l">
           <div class="label">${A("work.companyName")}</div>
              <div class="value">${a.companyName||"--"}</div>
            </div>
            <div class="r">
              <div class="label">${A("messages.labelSN")}</div>
              <div class="value">${a.npn||"--"}</div>
            </div>
          </li>

          <li>
            <div class="l">
              <div class="label">${A("messages.workingcondition")}</div>
              <div class="value">
                <span class='${a.judgeLevel?"status "+l[a.judgeLevel]:""} '></span>
                <span>${a.judgeLevel||"--"}</span>
              </div>
            </div>
            <div class="r">
              <div class="label">${A("work.drivingStatus")}</div>
              <div class="value">
                <span class='${i[a.driveState]?"status "+e[a.driveState]:""}'></span>
                <span>${i[a.driveState]||"--"}</span>
              </div>
            </div>
          </li>
          <li>
            <div class="l">
              <div class="label">${A("work.solStat")}</div>
              <div class="value">
                <span class='${d[a.solStat]?a.solStat==4?"status status_3":"status status_0":""}'></span>
                <span>${d[a.solStat]||"--"}</span>
              </div>
            </div>
            <div class="r">
              <div class="label">${A("work.differentialChains")}</div>
              <div class="value">${v[a.diffSource]||"--"} (${a.diffAge?a.diffAge+"s":"--"})</div>
            </div>
          </li>
          <li>
            <div class="l">
          <div class="label">${A("work.baseDis")}</div>
              <div class="value">${a.baseDist?(a.baseDist/1e3).toFixed(3)+"km":"--"}</div>
            </div>
            <div class="r">
               <div class="label">${A("work.terminalType")}</div>
              <div class="value">${a.terminalType||"--"}</div>
            </div>
          </li>

          <li>
            <div class="l">
              <div class="label">${A("work.lon")}</div>
              <div class="value">${j(a.posY)||"--"}</div>
            </div>
            <div class="r">
              <div class="label">${A("work.lat")}</div>
              <div class="value">${j(a.posX)||"--"}</div>

            </div>
          </li>
          <li>
            <div class="l">
               <div class="label">${A("work.CarStatus")}</div>
              <div class="value">${p}</div>
            </div>
            <div class="r">
              <div class="label"></div>
              <div class="value"></div>
            </div>
          </li>
        </ul>
        <ul class="btns_container">
          <li>
            <div class="btn ${c?"":"disabled"}" onclick='openRemote_markerPopup(${JSON.stringify(a)})'>${A("work.remoteManagement")}</div>
            <div class="btn" onclick='goTaskMachine_markerPopup(${JSON.stringify(a)})'>${A("devicelist.historyTrack")}</div>
          </li>
          <li>
            <div class="btn ${a.driveState==0||a.onlineTcp==0?"disabled":""}" onclick='openRealTimeChart_markerPopup(${JSON.stringify(a)})'>${A("messages.Realtimedrivingtrendchart")}</div>
            <div class="btn" onclick='gohistoryChart_markerPopup(${JSON.stringify(a)})'>${A("menus.historicaldrivingtrendchart")}</div>
          </li>
        </ul>
      </div>`}function _(a){const{terminalType:i,driveState:e,onlineTcp:l}=a;let d="";return l===0?d=oe:d=e==0?te:se,d}function x(a){const{terminalType:i,driveState:e}=a;let l="";return l=e==0?de:ce,l}function j(a){try{if(!a)return 0;let i=parseInt(a),e=(a-i)*60,l=parseInt(e),d=(e-l)*60;return`${i}\xB0${l}'${d.toFixed(3)}''`}catch(i){return console.log(i),a}}function za(a){L.push({path:"/machineryList",query:{sn:a.sn}})}function Ka(a){L.push({path:"/monitoring/taskMachine",query:{sn:a.sn,carId:a.carId}})}function ae(a){L.push({path:"/monitoring/historyChart",query:{sn:a.sn}})}function ee(a){a.driveState==0||a.onlineTcp==0||(J.value=a.sn,G.value.dialogVisible=!0)}function le(a){a.driveState==0&&($.value=!$.value,W.value=a.terminalType,H.value=a.version,Z.value=a.type,X.value=a.carId,J.value=a.sn,P.value=a.carName)}return(a,i)=>{var k,g,q,z,K,aa,ea,la,ia,ra;const e=b("Search"),l=b("el-icon"),d=b("el-autocomplete"),v=b("ArrowUpBold"),m=b("ArrowDownBold"),c=b("el-tooltip"),p=b("el-checkbox");return y(),f("div",ka,[h(ne,{ref_key:"sinoMapRef",ref:T,markerData:o(Q),markerDataHandle:o(I),markerDataHidden:o(O),mapCenter:M,mapRenderMode:"canvas"},null,8,["markerData","markerDataHandle","markerDataHidden","mapCenter"]),r("div",ga,[h(d,{style:be({width:Ha.value}),modelValue:V.value,"onUpdate:modelValue":i[0]||(i[0]=n=>V.value=n),"fetch-suggestions":Xa,placeholder:a.$t("messages.SNLabelSNcarName"),onSelect:Pa,clearable:""},{suffix:w(()=>[h(l,null,{default:w(()=>[h(e)]),_:1})]),default:w(({item:n})=>[r("div",{class:oa({bt_1:n.border&&n.markerId})},[n.markerId?(y(),f("div",ya,[r("span",null,s(n.sn),1),n.carName?(y(),f("span",ha," | "+s(n.carName),1)):N("",!0),n.npn?(y(),f("span",fa," | "+s(n.npn),1)):N("",!0)])):N("",!0),n.markerId?(y(),f("div",Ta,[r("span",null,s(n.companyName),1),n.tel?(y(),f("span",_a," | "+s(n.tel),1)):N("",!0)])):N("",!0),n.markerId?N("",!0):(y(),f("div",Ia,s(n),1))],2)]),_:1},8,["style","modelValue","placeholder"])]),r("div",{class:oa({statistics_box:!0,statistics_box_active:Y.value})},[r("div",{class:"header",onClick:i[1]||(i[1]=n=>Y.value=!Y.value)},[Y.value?(y(),sa(l,{key:1,color:"#fff"},{default:w(()=>[h(m)]),_:1})):(y(),sa(l,{key:0,color:"#fff"},{default:w(()=>[h(v)]),_:1}))]),r("ul",Sa,[r("li",Ca,[r("div",null,s((k=o(t).device)==null?void 0:k.totalDevice),1),r("div",null,s(a.$t("messages.total")),1)]),r("li",ba,[r("div",null,s((g=o(t).device)==null?void 0:g.onlineDevice),1),r("div",null,s(a.$t("messages.onlineCount")),1)]),r("li",wa,[r("div",null,s(((q=o(t).device)==null?void 0:q.totalDevice)-((z=o(t).device)==null?void 0:z.onlineDevice)),1),r("div",Na,[na(s(a.$t("messages.Offline"))+" ",1),Da])]),r("li",null,[r("div",null,s((K=o(t).workArea)==null?void 0:K.todayArea.toFixed(2)),1),r("div",null,s(a.$t("messages.todaysOperation")),1)]),r("li",null,[h(c,{class:"item",effect:"dark",disabled:U.value,content:((aa=o(t).workArea)==null?void 0:aa.totalArea)/1e4,placement:"top"},{default:w(()=>{var n;return[r("div",Ma,[r("span",{ref_key:"refName",ref:B,onMouseover:Wa},s(o(t).workArea?(((n=o(t).workArea)==null?void 0:n.totalArea)/1e4).toFixed(2):""),545)])]}),_:1},8,["disabled","content"]),r("div",null,s(a.$t("messages.cumulativeOperation")),1)]),r("li",null,[r("div",null,s((ea=o(t).workDuration)==null?void 0:ea.todayDuration),1),r("div",null,s(a.$t("messages.todayTime"))+"(h)",1)]),r("li",null,[r("div",null,s(o(t).workArea?((la=o(t).workDuration)==null?void 0:la.beforeDuration).toFixed(2):""),1),r("div",null,s(a.$t("messages.culTime"))+"(h)",1)]),Ea,r("li",Ra,[r("span",null,s((ia=o(t).drive)==null?void 0:ia.driving),1),r("div",null,[r("span",null,s(a.$t("messages.InOperation")),1),Ya])]),r("li",Ja,[r("span",null,s((ra=o(t).drive)==null?void 0:ra.standbyDevice),1),r("div",null,[r("span",null,s(a.$t("messages.Standby")),1),xa])])]),r("ul",Ba,[(y(!0),f(we,null,Ne(o(t).type,(n,ie)=>(y(),f("li",{key:ie},[r("label",null,[h(p,{size:"large",modelValue:n.checked,"onUpdate:modelValue":re=>n.checked=re,onChange:qa},null,8,["modelValue","onUpdate:modelValue"]),r("span",La,s(n.typeName),1)]),r("span",Qa,s(n.onlineCount),1),na("/ "),r("span",Ua,s(n.totalCount),1)]))),128)),$a])],2),h(Ae,{ref_key:"realTime",ref:G,sn:o(J),socketData:o(R).socketData},null,8,["sn","socketData"]),h(me,{isChange:o($),terminalType:o(W),paramVersionnum:o(H),paramType:o(Z),carId:o(X),sn:o(J),name:o(P)},null,8,["isChange","terminalType","paramVersionnum","paramType","carId","sn","name"])])}}});da=Ee(Fa,[["__scopeId","data-v-2edc4b4c"]])});export{Ge as __tla,da as default};
