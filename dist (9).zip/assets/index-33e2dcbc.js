import{A as te,a as re}from"./AG360_warn-40300f8f.js";import{S as se,A as ne,y as oe,g as de,__tla as ce}from"./index-5c53258d.js";import ue,{__tla as Ae}from"./realTimeChart-cf1dc08f.js";import{_ as ve,__tla as me}from"./index.vue_vue_type_script_setup_true_lang-29838c8f.js";import{s as pe,__tla as ke}from"./socket-82094fc8.js";import{d as ge,r as u,g as ta,A as ye,x as fe,y as he,B as _e,C as Se,a as Te,o as Ie,h as C,c as h,k as f,u as d,j as t,w,D as be,b as ra,t as s,p as sa,F as Ce,q as we,G as na,H as Me,I as Ee,f as y,e as M,_ as De,__tla as xe}from"./index-813e4ffd.js";import{f as Ne,o as Le,__tla as $e}from"./index-c479a3e3.js";import"./gcoord.esm-bundler-25b3e209.js";import"./index-9a6536ad.js";import{__tla as Re}from"./remoteAdjust-843f884e.js";import{__tla as Be}from"./index-84562cf5.js";import{__tla as Ue}from"./index-59b3e3f6.js";import{__tla as Ve}from"./remoteAdjust302-f8cab441.js";import{__tla as Je}from"./remoteAdjust502-32c81df9.js";import{__tla as Xe}from"./remoteAdjust501Pro-21927735.js";import{__tla as Ye}from"./remoteAdjust360-1f6bb3cf.js";let oa,Qe=Promise.all([(()=>{try{return ce}catch{}})(),(()=>{try{return Ae}catch{}})(),(()=>{try{return me}catch{}})(),(()=>{try{return ke}catch{}})(),(()=>{try{return xe}catch{}})(),(()=>{try{return $e}catch{}})(),(()=>{try{return Re}catch{}})(),(()=>{try{return Be}catch{}})(),(()=>{try{return Ue}catch{}})(),(()=>{try{return Ve}catch{}})(),(()=>{try{return Je}catch{}})(),(()=>{try{return Xe}catch{}})(),(()=>{try{return Ye}catch{}})()]).then(async()=>{const da="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAAAXNSR0IArs4c6QAAA5xJREFUWEftmO1RFEEQhrsz0AwgAiUCMQIlArkIlAiECNQIPCIQIxAi4IhAMpAM2nm3urd6e3t25riCuh9sFXXc7s7MM/3xTvcx7fnFe85HL4C7eujZLCgin4jolIh+MPNVL/izACrc2kGdMvNlD+STA4rIRyL6lcB0QT4KUEQOmPm+ZQEReUtEf4jolb57RkRwNe7jakJuDSgiX8vM52VyAL6vgSZwK2ZeiwhgAd0FuRWggzPjpZA1OBu0DWQ3YIAD2IEuOIGE+4no1rl1sFwMhwTyJMvuLsAAt4FriegLEcHduEbIsvB3Ivqs9x+I6GghDI7V3Xgd8oM5J1cTMIMrE2FhCjADZAHHMx9jPWFQjedFwCARg+UcHFxpGWpZ2gUZYnQx2VqA3gXejR4OVoPWTdytMYoNTBJKY9M2tgiHgT0uxvH008XaSr/DarAoLAt3Q3o8JJ6bZT2k3W/CdQHq4h4StxBnI5yTDw9p72FD31zWT5IqJsXWSeIWj5ZMRTpY8oqZT1R64FaERpSlITyY+SiDbbrYDxKRx0CumXmlkIAB9HhMiojF+QUzwwPbyUwcsAtkzZ0iMsgSM7/eGTCJyZrO+RNlU3NhmA9hc+0hu1ys7kEmY1EcSZslS4aYmySUaiCSBi4dYPTY+5edJk3AsNiYwQrr6zwTaatW8DnLdoX5W1TgpmwUMTlcpajFvXtmhq6OV0uoTZDxicVM1/A//uJ9QJrOpVKkMEMxUarqQweYxmEVMJMGIkLGmWjb3ChCAWUiPVrZRDxJtBrgMZdUblqwEUNeakYrOf2rWi7E27V3Zy2TZxZcgquItoeEhZGxQ7WTXS65JnWiiCBJMHY5BjVYrRhNi8hEagB0uASmYyym8XU8iZxYz2rCzILYiSXDeYmJi4olrDexxwCsNlLBM2fMjMLWMhhqgIyezZEBxk5sBpn0ueMxpTqHREKVc6fZ/kabdmw8wllbOhyJ0RhpFidNzwi5BKduxAYBaF2bZTV+TcBG/Dns68q0NViSmZklS3/xWxsi22h6wLtsNZ18iPEZmqaJVZsy42IjQnqx9m6F6FYzN9FBgCPuMH91kxjXc9RFSIzzcFYuobW8jIe9h1OroeOz7g3zjMmSJWMT0MWV9RGTHeui1pNYQYp4u3HHIZLjg55EmBJFAnSw+fNJF6DTMLhy6EEq0gNrA/adus93exgH6EnBWpvL7ncDtiZ6qucvgLtadu8t+B8MoClHpWe61AAAAABJRU5ErkJggg==",ca="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAOCAYAAAAfSC3RAAAACXBIWXMAAAsSAAALEgHS3X78AAAAR0lEQVQokbXSwQ0AIAhDUTCu0/2X6S715I1EQez95x3AJVllo1SZ2cwGJPUkXoUktaVUmBIjpV88KT0iAAFIv8/fO0bz6pMvc3ciKF48m5QAAAAASUVORK5CYII=",ua="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAOCAYAAAAfSC3RAAAACXBIWXMAAAsSAAALEgHS3X78AAAARklEQVQoka3SsREAIAhDUfBcJ/svk11iZWcBEfp/rwgpKZxbVhURuxuQ1JdYCknqSq2wJb6UeRGAAJSG9cWOMiO6YbpPfgA6EB4Oj8gJUQAAAABJRU5ErkJggg==",Aa="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAOCAYAAAAfSC3RAAAACXBIWXMAAAsSAAALEgHS3X78AAAARklEQVQoka3SwQ0AIAhDUTCu0/2X6S715NEoFe4/L2lISeHcsKqImNWApL7Ep5CktlQKSyIAAThO3iPelB6xovSIbpjuky9eLxn0ZcBMNwAAAABJRU5ErkJggg==",va="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAOCAYAAAAfSC3RAAAACXBIWXMAAAsSAAALEgHS3X78AAAAQ0lEQVQoka3SwQkAIAxD0VZcJ/sv013iWRC0Mb1/HoQmyVBuSFVEzG5QVfwSn0IABLCN4RdPil+8KR6xo3hENUz1yRff1BXa/ns3PAAAAABJRU5ErkJggg==",ma="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAOCAYAAAAfSC3RAAAACXBIWXMAAAsSAAALEgHS3X78AAAAQElEQVQoka3SsQ0AIBBCUc64DvuPh5WdiYJH//MaShKSjagCMN2ApL7Ep5CktmSFlnhS+sWb0iM6So+YhpWefAHLVxPNgv3U4wAAAABJRU5ErkJggg==",E=x=>(Me("data-v-b9d81105"),x=x(),Ee(),x),pa={class:"map_container"},ka={class:"search_box"},ga={key:0},ya={key:0},fa={key:1},ha={key:1},_a={key:0},Sa={key:2},Ta={class:"top"},Ia={class:"top_line"},ba={class:"top_line"},Ca={class:"top_line"},wa={class:"outside"},Ma=E(()=>t("div",{class:"offline_area"},null,-1)),Ea={style:{"text-overflow":"ellipsis",overflow:"hidden"}},Da=E(()=>t("div",{style:{height:"2px",width:"100%","background-color":"rgba(0, 218, 216, 0.3)",margin:"15px 0"}},null,-1)),xa={class:"bottom_li"},Na=E(()=>t("div",null,null,-1)),La={class:"bottom_li"},$a=E(()=>t("div",null,null,-1)),Ra={class:"center"},Ba={class:"label"},Ua={class:"value"},Va={class:"value"},Ja=E(()=>t("br",null,null,-1)),Xa=ge({__name:"index",setup(x){const _=u(),{t:A}=ta(),{locale:Ya}=ta(),B=u(null);let Qa=500;const U=ye(),Y=fe(),N=pe();let V=u([]),Q=u([]),T=u({}),r=u({});const J=u(!0),L=u(!1);let $=u(),P=u(),O=u(),W=u(),H=u(),F=u(),G=u(),X=u(!1);const Z=u(""),D=he({markerId:"",mapCenter:[]});window.goMachineryList_markerPopup=qa,window.goTaskMachine_markerPopup=za,window.gohistoryChart_markerPopup=Ka,window.openRealTimeChart_markerPopup=ae,window.openRemote_markerPopup=ee,_e(()=>N.socketData,a=>{Fa(a)},{deep:!0});function Pa(){let a=B.value.parentNode.offsetWidth;B.value.offsetWidth>a?J.value=!1:J.value=!0}const Oa=Se(()=>Ya.value=="zh"?"280px":"350px");Te(()=>{N.close()}),Ie(()=>{N.connect()}),Ga(),Za();function Wa(a,i){let e=V.value.filter(l=>{if(l.sn&&l.sn.includes(a)||l.npn&&l.npn.includes(a)||l.carName&&l.carName.includes(a)||l.companyName&&l.companyName.includes(a)||l.tel&&l.tel.includes(a))return!0});if(e.length<=0){i(["\u65E0\u6570\u636E"]);return}e.length>3&&(e.length=3),e.forEach(l=>{l.border=!0,l.value=l.sn}),e[e.length-1].border=!1,i(e)}function Ha(a){a.markerId&&(D.markerId="",D.markerId=a.markerId)}function Fa(a){if(a.module=="farm"&&a.type=="farmPt"){let{action:i,data:e}=a;if(i=="upline")if(_.value.isIconChange){const l=e.sn,o=e.posY,v=e.posX,m=e.onlineTcp,c=e.driveState,p=I(e),k=_.value.iconChangeLimit?S(e):R(e),g=b(e);T.value={markerId:l,onlineTcp:m,driveState:c,markerLng:o,markerLat:v,markerType:p,markerIcon:k,markerPopup:g,markerHandle:"add"}}else{const l=e.sn,o=e.posY,v=e.posX,m=I(e),c=S(e),p=b(e),k=e.onlineTcp,g=e.driveState;T.value={markerId:l,onlineTcp:k,driveState:g,markerLng:o,markerLat:v,markerType:m,markerIcon:c,markerPopup:p,markerHandle:"add"}}if(i=="offline")if(_.value.isIconChange){const l=e.sn,o=e.posY,v=e.posX,m=e.onlineTcp,c=e.driveState,p=I(e),k=_.value.iconChangeLimit?S(e):R(e),g=b(e);T.value={markerId:l,onlineTcp:m,driveState:c,markerLng:o,markerLat:v,markerType:p,markerIcon:k,markerPopup:g,markerHandle:"delete"}}else{const l=e.sn,o=e.posY,v=e.posX,m=I(e),c=S(e),p=b(e),k=e.onlineTcp,g=e.driveState;T.value={markerId:l,onlineTcp:k,driveState:g,markerLng:o,markerLat:v,markerType:m,markerIcon:c,markerPopup:p,markerHandle:"delete"}}if(i=="online")if(_.value.isIconChange){const l=_.value.iconChangeLimit?S(e):R(e),o=e.sn,v=e.posY,m=e.onlineTcp,c=e.driveState,p=e.posX,k=I(e),g=b(e);T.value={markerId:o,markerLng:v,markerLat:p,onlineTcp:m,driveState:c,markerType:k,markerIcon:l,markerPopup:g,markerHandle:"update"}}else{const l=S(e),o=e.sn,v=e.posY,m=e.posX,c=e.onlineTcp,p=e.driveState,k=I(e),g=b(e);T.value={markerId:o,markerLng:v,markerLat:m,onlineTcp:c,driveState:p,markerType:k,markerIcon:l,markerPopup:g,markerHandle:"update"}}}if(a.module=="farm"&&a.type=="monitor"){const{data:i}=a;r.value.device.totalDevice=i.totalDevice,r.value.device.onlineDevice=i.onlineDevice,r.value.drive.driving=i.driving,r.value.drive.standbyDevice=i.standbyDevice;const e=i.typeCounts;r.value.type.forEach((l,o)=>{l.onlineCount=e[o].onlineCount,l.totalCount=e[o].totalCount})}if(a.module=="farm"&&a.type=="monitorArea"){const{data:i}=a;r.value.workArea.todayArea=i.todayArea,r.value.workArea.totalArea=i.totalArea,r.value.workDuration.todayDuration=i.todayDuration,r.value.workDuration.beforeDuration=i.beforeDuration}if(a.module=="farm"&&a.type=="monitorCarNum"){const{data:i}=a;r.value.drive.driving=i.driving,r.value.drive.standbyDevice=i.standbyDevice,r.value.device.onlineDevice=i.driving+i.standbyDevice}}async function Ga(){const{data:a}=await Ne();r.value=a,r.value.type.forEach(i=>i.checked=!0)}async function Za(){const{data:a}=await Le({});let i=a.onlineFarmMachines,e=[];i.map(l=>{l.posX!==null&&e.push(l)}),i.forEach(l=>{l.markerId=l.sn,l.markerLng=l.posY,l.markerLat=l.posX,l.markerType=I(l),e.length>Qa?_.value.iconChangeLimit?l.markerIcon=S(l):l.markerIcon=R(l):l.markerIcon=S(l),l.markerPopup=b(l),l.driveState=l.driveState}),i=i.filter(l=>l.markerLng||l.markerLng==0),V.value=i,Y.query.markerId&&(D.markerId=Y.query.markerId),D.center=i.map(l=>[l.posY,l.posX])}function ja(){let a=r.value.type.filter(i=>!i.checked);a=a.map(i=>i.typeName),Q.value=a}function I(a){return a.terminalType&&a.terminalType.includes("AG360")?"AG360":a.terminalType&&a.terminalType.includes("AG501")&&a.terminalType!="AG501Pro"?"AG501":a.terminalType&&a.terminalType=="AG501Pro"?"AG501Pro":a.terminalType&&a.terminalType.includes("AG502")?"AG502":a.terminalType&&a.terminalType.includes("AG302")&&a.terminalType!="AG302Android"?"AG302":a.terminalType&&a.terminalType=="AG302Android"?"AG302Android":a.terminalType&&a.terminalType.includes("MC100")?"MC100":a.terminalType&&a.terminalType.includes("SA200")?"SA200":a.terminalType&&a.terminalType.includes("MT801")?"MT801":a.terminalType&&a.terminalType.includes("MT802")?"MT802":""}function b(a){const i={0:"\u975E\u81EA\u52A8\u9A7E\u9A76",1:"\u81EA\u52A8\u9A7E\u9A76",2:"\u81EA\u52A8\u9A7E\u9A76"},e={0:"status_1",1:"status_2",2:"status_3",null:"status_1"},l={\u4F18:"status_3",\u4E2D:"status_2",\u5DEE:"status_0",null:"status_1"},o={0:"\u65E0\u6548\u89E3",1:"\u5355\u70B9\u89E3",2:"\u5DEE\u5206\u89E3",3:"\u6D6E\u52A8\u89E3",4:"\u56FA\u5B9A\u89E3"},v={0:"\u7535\u53F0",1:"\u7F51\u7EDC",3:"\u7F57\u7F51"},m={0:ca,1:ua,2:Aa,3:va,4:ma};let c=!0;a.onlineTcp===0||a.driveState!=0?c=!1:c=!0;const p=a.cardUsage==1?"\u53611":a.cardUsage==2?"\u53612":"\u53CC\u5361";return`<div class="map_popup">

        <ul class="popup_container">
         <li>
            <div class="le">
              <span > <img class="sate" src=${da}></span>
             <span class="value">${a.satNum||"--"}</span>
            </div>
            <div class="re" >
              <div class="value" style="margin-left: auto;margin-right:20px">
                <img src=${m[a.netSignal]}>
                <span>4G</span>
              </div>
            </div>
          </li>
          <li>
            <div class="l">
              <div class="label">${A("messages.carName")}</div>
              <div class="value">${a.carName||"--"}</div>
            </div>
            <div class="r">
              <div class="label">SN</div>
              <div class="value"  style="cursor: pointer;text-decoration: underline;" onclick='goMachineryList_markerPopup(${JSON.stringify(a)})'>${a.sn||"--"}</div>
            </div>
          </li>
          <li>
            <div class="l">
           <div class="label">${A("work.companyName")}</div>
              <div class="value">${a.companyName||"--"}</div>
            </div>
            <div class="r">
              <div class="label">${A("messages.labelSN")}</div>
              <div class="value">${a.npn||"--"}</div>
            </div>
          </li>

          <li>
            <div class="l">
              <div class="label">${A("messages.workingcondition")}</div>
              <div class="value">
                <span class='${a.judgeLevel?"status "+l[a.judgeLevel]:""} '></span>
                <span>${a.judgeLevel||"--"}</span>
              </div>
            </div>
            <div class="r">
              <div class="label">${A("work.drivingStatus")}</div>
              <div class="value">
                <span class='${i[a.driveState]?"status "+e[a.driveState]:""}'></span>
                <span>${i[a.driveState]||"--"}</span>
              </div>
            </div>
          </li>
          <li>
            <div class="l">
              <div class="label">${A("work.solStat")}</div>
              <div class="value">
                <span class='${o[a.solStat]?a.solStat==4?"status status_3":"status status_0":""}'></span>
                <span>${o[a.solStat]||"--"}</span>
              </div>
            </div>
            <div class="r">
              <div class="label">${A("work.differentialChains")}</div>
              <div class="value">${v[a.diffSource]||"--"} (${a.diffAge?a.diffAge+"s":"--"})</div>
            </div>
          </li>
          <li>
            <div class="l">
          <div class="label">${A("work.baseDis")}</div>
              <div class="value">${a.baseDist?(a.baseDist/1e3).toFixed(3)+"km":"--"}</div>
            </div>
            <div class="r">
               <div class="label">${A("work.terminalType")}</div>
              <div class="value">${a.terminalType||"--"}</div>
            </div>
          </li>

          <li>
            <div class="l">
              <div class="label">${A("work.lon")}</div>
              <div class="value">${j(a.posY)||"--"}</div>
            </div>
            <div class="r">
              <div class="label">${A("work.lat")}</div>
              <div class="value">${j(a.posX)||"--"}</div>

            </div>
          </li>
          <li>
            <div class="l">
               <div class="label">${A("work.CarStatus")}</div>
              <div class="value">${p}</div>
            </div>
            <div class="r">
              <div class="label"></div>
              <div class="value"></div>
            </div>
          </li>
        </ul>
        <ul class="btns_container">
          <li>
            <div class="btn ${c?"":"disabled"}" onclick='openRemote_markerPopup(${JSON.stringify(a)})'>${A("work.remoteManagement")}</div>
            <div class="btn" onclick='goTaskMachine_markerPopup(${JSON.stringify(a)})'>${A("devicelist.historyTrack")}</div>
          </li>
          <li>
            <div class="btn ${a.driveState==0||a.onlineTcp==0?"disabled":""}" onclick='openRealTimeChart_markerPopup(${JSON.stringify(a)})'>${A("messages.Realtimedrivingtrendchart")}</div>
            <div class="btn" onclick='gohistoryChart_markerPopup(${JSON.stringify(a)})'>${A("menus.historicaldrivingtrendchart")}</div>
          </li>
        </ul>
      </div>`}function S(a){const{terminalType:i,driveState:e,onlineTcp:l}=a;let o="";return l===0?o=ne:o=e==0?te:re,o}function R(a){const{terminalType:i,driveState:e}=a;let l="";return l=e==0?oe:de,l}function j(a){try{if(!a)return 0;let i=parseInt(a),e=(a-i)*60,l=parseInt(e),o=(e-l)*60;return`${i}\xB0${l}'${o.toFixed(3)}''`}catch(i){return console.log(i),a}}function qa(a){U.push({path:"/machineryList",query:{sn:a.sn}})}function za(a){U.push({path:"/monitoring/taskMachine",query:{sn:a.sn}})}function Ka(a){U.push({path:"/monitoring/historyChart",query:{sn:a.sn}})}function ae(a){a.driveState==0||a.onlineTcp==0||($.value=a.sn,P.value.dialogVisible=!0)}function ee(a){a.driveState==0&&(X.value=!X.value,O.value=a.terminalType,W.value=a.version,G.value=a.type,H.value=a.carId,$.value=a.sn,F.value=a.carName)}return(a,i)=>{var k,g,q,z,K,aa,ea,la,ia;const e=C("Search"),l=C("el-icon"),o=C("el-autocomplete"),v=C("ArrowUpBold"),m=C("ArrowDownBold"),c=C("el-tooltip"),p=C("el-checkbox");return y(),h("div",pa,[f(se,{ref_key:"sinoMapRef",ref:_,markerData:d(V),markerDataHandle:d(T),markerDataHidden:d(Q),mapCenter:D,mapRenderMode:"canvas"},null,8,["markerData","markerDataHandle","markerDataHidden","mapCenter"]),t("div",ka,[f(o,{style:be({width:Oa.value}),modelValue:Z.value,"onUpdate:modelValue":i[0]||(i[0]=n=>Z.value=n),"fetch-suggestions":Wa,placeholder:a.$t("messages.SNLabelSNcarName"),onSelect:Ha,clearable:""},{suffix:w(()=>[f(l,null,{default:w(()=>[f(e)]),_:1})]),default:w(({item:n})=>[t("div",{class:na({bt_1:n.border&&n.markerId})},[n.markerId?(y(),h("div",ga,[t("span",null,s(n.sn),1),n.carName?(y(),h("span",ya," | "+s(n.carName),1)):M("",!0),n.npn?(y(),h("span",fa," | "+s(n.npn),1)):M("",!0)])):M("",!0),n.markerId?(y(),h("div",ha,[t("span",null,s(n.companyName),1),n.tel?(y(),h("span",_a," | "+s(n.tel),1)):M("",!0)])):M("",!0),n.markerId?M("",!0):(y(),h("div",Sa,s(n),1))],2)]),_:1},8,["style","modelValue","placeholder"])]),t("div",{class:na({statistics_box:!0,statistics_box_active:L.value})},[t("div",{class:"header",onClick:i[1]||(i[1]=n=>L.value=!L.value)},[L.value?(y(),ra(l,{key:1,color:"#fff"},{default:w(()=>[f(m)]),_:1})):(y(),ra(l,{key:0,color:"#fff"},{default:w(()=>[f(v)]),_:1}))]),t("ul",Ta,[t("li",Ia,[t("div",null,s((k=d(r).device)==null?void 0:k.totalDevice),1),t("div",null,s(a.$t("messages.total")),1)]),t("li",ba,[t("div",null,s((g=d(r).device)==null?void 0:g.onlineDevice),1),t("div",null,s(a.$t("messages.onlineCount")),1)]),t("li",Ca,[t("div",null,s((q=d(r).device)==null?void 0:q.offlineDevice),1),t("div",wa,[sa(s(a.$t("messages.Offline"))+" ",1),Ma])]),t("li",null,[t("div",null,s((z=d(r).workArea)==null?void 0:z.todayArea.toFixed(2)),1),t("div",null,s(a.$t("messages.todaysOperation")),1)]),t("li",null,[f(c,{class:"item",effect:"dark",disabled:J.value,content:((K=d(r).workArea)==null?void 0:K.totalArea)/1e4,placement:"top"},{default:w(()=>{var n;return[t("div",Ea,[t("span",{ref_key:"refName",ref:B,onMouseover:Pa},s(d(r).workArea?(((n=d(r).workArea)==null?void 0:n.totalArea)/1e4).toFixed(2):""),545)])]}),_:1},8,["disabled","content"]),t("div",null,s(a.$t("messages.cumulativeOperation")),1)]),t("li",null,[t("div",null,s((aa=d(r).workDuration)==null?void 0:aa.todayDuration),1),t("div",null,s(a.$t("messages.todayTime"))+"(h)",1)]),t("li",null,[t("div",null,s(d(r).workArea?((ea=d(r).workDuration)==null?void 0:ea.beforeDuration).toFixed(2):""),1),t("div",null,s(a.$t("messages.culTime"))+"(h)",1)]),Da,t("li",xa,[t("span",null,s((la=d(r).drive)==null?void 0:la.driving),1),t("div",null,[t("span",null,s(a.$t("messages.InOperation")),1),Na])]),t("li",La,[t("span",null,s((ia=d(r).drive)==null?void 0:ia.standbyDevice),1),t("div",null,[t("span",null,s(a.$t("messages.Standby")),1),$a])])]),t("ul",Ra,[(y(!0),h(Ce,null,we(d(r).type,(n,le)=>(y(),h("li",{key:le},[t("label",null,[f(p,{size:"large",modelValue:n.checked,"onUpdate:modelValue":ie=>n.checked=ie,onChange:ja},null,8,["modelValue","onUpdate:modelValue"]),t("span",Ba,s(n.typeName),1)]),t("span",Ua,s(n.onlineCount),1),sa("/ "),t("span",Va,s(n.totalCount),1)]))),128)),Ja])],2),f(ue,{ref_key:"realTime",ref:P,sn:d($),socketData:d(N).socketData},null,8,["sn","socketData"]),f(ve,{isChange:d(X),terminalType:d(O),paramVersionnum:d(W),paramType:d(G),carId:d(H),sn:d($),name:d(F)},null,8,["isChange","terminalType","paramVersionnum","paramType","carId","sn","name"])])}}});oa=De(Xa,[["__scopeId","data-v-b9d81105"]])});export{Qe as __tla,oa as default};
